/*
 * Listings Page
 * Design: Header with "Evcil Hayvan İlanları", horizontal filter chips,
 * comprehensive filter panel (breed, age, location, gender), search,
 * sorting (distance, newest, oldest), vertical pet cards.
 */

import { useApp } from '@/contexts/AppContext';
import { PawLogo } from '@/components/PawLogo';
import { PetCard } from '@/components/PetCard';
import { BottomNav } from '@/components/BottomNav';
import { MOCK_PETS } from '@/const';
import { Bell, PawPrint, Cat, Dog, Search, Heart, SlidersHorizontal, X, MapPin, SortAsc } from 'lucide-react';
import { useState, useMemo, useCallback } from 'react';

type FilterType = 'all' | 'cat' | 'dog' | 'lost' | 'adopt';
type SortType = 'newest' | 'oldest' | 'distance' | 'name';

const filters: { id: FilterType; label: string; icon: React.ReactNode }[] = [
  { id: 'all', label: 'Tümü', icon: null },
  { id: 'cat', label: 'Kedi', icon: <Cat className="w-4 h-4" /> },
  { id: 'dog', label: 'Köpek', icon: <Dog className="w-4 h-4" /> },
  { id: 'lost', label: 'Kayıp', icon: <Search className="w-4 h-4" /> },
  { id: 'adopt', label: 'Sahiplen', icon: <Heart className="w-4 h-4" /> },
];

const breeds = ['Tekir Kedi', 'Golden Retriever', 'Persian', 'Labrador', 'Van Kedisi', 'Kangal', 'Sokak Kedisi', 'Sokak Köpeği'];
const ages = ['0 - 1 yaş', '1 - 2 yaş', '2 - 5 yaş', '5 yaş ve üzeri'];
const genders = ['Erkek', 'Dişi'];

const sortOptions: { id: SortType; label: string }[] = [
  { id: 'distance', label: 'Yakına Göre' },
  { id: 'newest', label: 'En Yeni' },
  { id: 'oldest', label: 'En Eski' },
  { id: 'name', label: 'İsme Göre' },
];

export default function ListingsPage() {
  const { setActiveTab, userListings } = useApp();
  const pets = userListings.length > 0 ? userListings : MOCK_PETS;
  const [activeFilter, setActiveFilter] = useState<FilterType>('all');
  const [showFilters, setShowFilters] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<SortType>('newest');

  // Advanced filters
  const [selectedBreeds, setSelectedBreeds] = useState<string[]>([]);
  const [selectedAges, setSelectedAges] = useState<string[]>([]);
  const [selectedGender, setSelectedGender] = useState<string>('');
  const [locationQuery, setLocationQuery] = useState('');

  const toggleBreed = useCallback((breed: string) => {
    setSelectedBreeds(prev =>
      prev.includes(breed) ? prev.filter(b => b !== breed) : [...prev, breed]
    );
  }, []);

  const toggleAge = useCallback((age: string) => {
    setSelectedAges(prev =>
      prev.includes(age) ? prev.filter(a => a !== age) : [...prev, age]
    );
  }, []);

  const clearAllFilters = () => {
    setActiveFilter('all');
    setSearchQuery('');
    setSelectedBreeds([]);
    setSelectedAges([]);
    setSelectedGender('');
    setLocationQuery('');
    setSortBy('newest');
    setShowFilters(false);
  };

  const hasActiveFilters = searchQuery || selectedBreeds.length > 0 || selectedAges.length > 0 || selectedGender || locationQuery || activeFilter !== 'all';
  const filterCount = (searchQuery ? 1 : 0) + selectedBreeds.length + selectedAges.length + (selectedGender ? 1 : 0) + (locationQuery ? 1 : 0) + (activeFilter !== 'all' ? 1 : 0);

  const filteredPets = useMemo(() => {
    let result = [...pets];

    // Basic filter
    switch (activeFilter) {
      case 'cat': result = result.filter(p => p.type === 'cat'); break;
      case 'dog': result = result.filter(p => p.type === 'dog'); break;
      case 'lost': result = result.filter(p => p.status === 'lost' || p.status === 'found'); break;
      case 'adopt': result = result.filter(p => p.status === 'adoption'); break;
    }

    // Search
    if (searchQuery) {
      const q = searchQuery.toLowerCase();
      result = result.filter(p =>
        p.name.toLowerCase().includes(q) ||
        p.breed.toLowerCase().includes(q) ||
        p.location.toLowerCase().includes(q) ||
        p.description.toLowerCase().includes(q)
      );
    }

    // Breed filter
    if (selectedBreeds.length > 0) {
      result = result.filter(p => selectedBreeds.includes(p.breed));
    }

    // Age filter
    if (selectedAges.length > 0) {
      result = result.filter(p => selectedAges.some(age => p.age.includes(age)));
    }

    // Gender filter
    if (selectedGender) {
      result = result.filter(p => p.gender === (selectedGender === 'Erkek' ? 'male' : 'female'));
    }

    // Location filter
    if (locationQuery) {
      const q = locationQuery.toLowerCase();
      result = result.filter(p => p.location.toLowerCase().includes(q));
    }

    // Sorting
    switch (sortBy) {
      case 'newest': result.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()); break;
      case 'oldest': result.sort((a, b) => new Date(a.createdAt).getTime() - new Date(b.createdAt).getTime()); break;
      case 'distance': result.sort((a, b) => parseFloat(a.distance) - parseFloat(b.distance)); break;
      case 'name': result.sort((a, b) => a.name.localeCompare(b.name, 'tr')); break;
    }

    return result;
  }, [activeFilter, searchQuery, selectedBreeds, selectedAges, selectedGender, locationQuery, sortBy, pets]);

  return (
    <div className="min-h-screen bg-[#FFFBF0] pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#FFFBF0]/95 backdrop-blur-lg px-4 pt-4 pb-3">
        <div className="flex items-center justify-between mb-3">
          <PawLogo size="sm" />
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowFilters(!showFilters)}
              className={`relative w-9 h-9 rounded-full flex items-center justify-center shadow-sm transition-colors ${
                hasActiveFilters ? 'bg-[#D97706] text-white' : 'bg-white text-[#78350F]'
              }`}
            >
              <SlidersHorizontal className="w-4 h-4" />
              {filterCount > 0 && (
                <span className="absolute -top-1 -right-1 w-4 h-4 bg-red-500 rounded-full text-white text-[9px] font-bold flex items-center justify-center">
                  {filterCount}
                </span>
              )}
            </button>
            <button className="relative w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-sm">
              <Bell className="w-4 h-4 text-[#78350F]" />
            </button>
          </div>
        </div>
        <h1 className="font-[Quicksand] font-bold text-2xl text-[#2D1B00]">Evcil Hayvan İlanları</h1>
      </header>

      {/* Search Bar */}
      <div className="px-4 py-3">
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-[#92400E]/40" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="İsim, cins veya konum ara..."
            className="w-full px-4 py-3 pl-11 rounded-xl border-2 border-[#F3E8D0] bg-white text-sm text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors"
          />
          {searchQuery && (
            <button
              onClick={() => setSearchQuery('')}
              className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 bg-[#F3E8D0] rounded-full flex items-center justify-center"
            >
              <X className="w-3 h-3 text-[#78350F]" />
            </button>
          )}
        </div>
      </div>

      {/* Filter Chips */}
      <div className="px-4 py-2">
        <div className="flex gap-2 overflow-x-auto pb-1 scrollbar-hide">
          {filters.map((filter) => (
            <button
              key={filter.id}
              onClick={() => setActiveFilter(filter.id)}
              className={`flex items-center gap-1.5 px-4 py-2 rounded-full text-sm font-semibold whitespace-nowrap transition-all duration-200 ${
                activeFilter === filter.id
                  ? 'bg-[#D97706] text-white shadow-md shadow-amber-600/20'
                  : 'bg-white text-[#78350F]/60 border border-[#F3E8D0]'
              }`}
            >
              {filter.icon}
              {filter.label}
            </button>
          ))}
        </div>
      </div>

      {/* Advanced Filters Panel */}
      {showFilters && (
        <div className="px-4 pb-2 space-y-4 animate-in slide-in-from-top-2 duration-200">
          {/* Sort */}
          <div className="bg-white rounded-2xl p-4 shadow-sm shadow-amber-900/5">
            <div className="flex items-center gap-2 mb-3">
              <SortAsc className="w-4 h-4 text-[#D97706]" />
              <h3 className="font-[Quicksand] font-bold text-sm text-[#2D1B00]">Sıralama</h3>
            </div>
            <div className="flex gap-2 flex-wrap">
              {sortOptions.map((opt) => (
                <button
                  key={opt.id}
                  onClick={() => setSortBy(opt.id)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    sortBy === opt.id
                      ? 'bg-[#FEF3C7] text-[#78350F]'
                      : 'bg-[#FFFBF0] text-[#92400E]/50 border border-[#F3E8D0]'
                  }`}
                >
                  {opt.label}
                </button>
              ))}
            </div>
          </div>

          {/* Breed Filter */}
          <div className="bg-white rounded-2xl p-4 shadow-sm shadow-amber-900/5">
            <div className="flex items-center gap-2 mb-3">
              <PawPrint className="w-4 h-4 text-[#D97706]" />
              <h3 className="font-[Quicksand] font-bold text-sm text-[#2D1B00]">Cins</h3>
            </div>
            <div className="flex gap-2 flex-wrap">
              {breeds.map((breed) => (
                <button
                  key={breed}
                  onClick={() => toggleBreed(breed)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    selectedBreeds.includes(breed)
                      ? 'bg-[#D97706] text-white'
                      : 'bg-[#FFFBF0] text-[#92400E]/60 border border-[#F3E8D0]'
                  }`}
                >
                  {breed}
                </button>
              ))}
            </div>
          </div>

          {/* Age Filter */}
          <div className="bg-white rounded-2xl p-4 shadow-sm shadow-amber-900/5">
            <div className="flex items-center gap-2 mb-3">
              <svg className="w-4 h-4 text-[#D97706]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M12 6v6l4 2"/></svg>
              <h3 className="font-[Quicksand] font-bold text-sm text-[#2D1B00]">Yaş</h3>
            </div>
            <div className="flex gap-2 flex-wrap">
              {ages.map((age) => (
                <button
                  key={age}
                  onClick={() => toggleAge(age)}
                  className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    selectedAges.includes(age)
                      ? 'bg-[#D97706] text-white'
                      : 'bg-[#FFFBF0] text-[#92400E]/60 border border-[#F3E8D0]'
                  }`}
                >
                  {age}
                </button>
              ))}
            </div>
          </div>

          {/* Gender Filter */}
          <div className="bg-white rounded-2xl p-4 shadow-sm shadow-amber-900/5">
            <div className="flex items-center gap-2 mb-3">
              <svg className="w-4 h-4 text-[#D97706]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/><circle cx="9" cy="7" r="4"/><path d="M23 21v-2a4 4 0 0 0-3-3.87"/><path d="M16 3.13a4 4 0 0 1 0 7.75"/></svg>
              <h3 className="font-[Quicksand] font-bold text-sm text-[#2D1B00]">Cinsiyet</h3>
            </div>
            <div className="flex gap-2">
              {genders.map((g) => (
                <button
                  key={g}
                  onClick={() => setSelectedGender(selectedGender === g ? '' : g)}
                  className={`px-4 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                    selectedGender === g
                      ? 'bg-[#D97706] text-white'
                      : 'bg-[#FFFBF0] text-[#92400E]/60 border border-[#F3E8D0]'
                  }`}
                >
                  {g}
                </button>
              ))}
            </div>
          </div>

          {/* Location Filter */}
          <div className="bg-white rounded-2xl p-4 shadow-sm shadow-amber-900/5">
            <div className="flex items-center gap-2 mb-3">
              <MapPin className="w-4 h-4 text-[#D97706]" />
              <h3 className="font-[Quicksand] font-bold text-sm text-[#2D1B00]">Konum</h3>
            </div>
            <div className="relative">
              <MapPin className="absolute right-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#D97706]/40" />
              <input
                type="text"
                value={locationQuery}
                onChange={(e) => setLocationQuery(e.target.value)}
                placeholder="İlçe veya semt ara... (örn: Kadıköy)"
                className="w-full px-4 py-2.5 pr-10 rounded-xl border-2 border-[#F3E8D0] bg-[#FFFBF0] text-sm text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors"
              />
            </div>
          </div>

          {/* Clear All */}
          {hasActiveFilters && (
            <button
              onClick={clearAllFilters}
              className="w-full py-2.5 text-sm font-semibold text-red-500 hover:text-red-600 transition-colors flex items-center justify-center gap-1.5"
            >
              <X className="w-4 h-4" />
              Tüm Filtreleri Temizle
            </button>
          )}

          <button
            onClick={() => setShowFilters(false)}
            className="w-full py-3 bg-[#D97706] text-white font-[Quicksand] font-bold text-sm rounded-xl shadow-md shadow-amber-600/20 active:scale-[0.97] transition-transform"
          >
            Filtreleri Uygula
          </button>
        </div>
      )}

      {/* Active Filters Tags */}
      {hasActiveFilters && !showFilters && (
        <div className="px-4 py-2 flex gap-2 flex-wrap">
          {activeFilter !== 'all' && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#FEF3C7] rounded-full text-xs font-semibold text-[#78350F]">
              {filters.find(f => f.id === activeFilter)?.label}
              <button onClick={() => setActiveFilter('all')}><X className="w-3 h-3" /></button>
            </span>
          )}
          {searchQuery && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#FEF3C7] rounded-full text-xs font-semibold text-[#78350F]">
              "{searchQuery}"
              <button onClick={() => setSearchQuery('')}><X className="w-3 h-3" /></button>
            </span>
          )}
          {selectedBreeds.map(b => (
            <span key={b} className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#FEF3C7] rounded-full text-xs font-semibold text-[#78350F]">
              {b}
              <button onClick={() => toggleBreed(b)}><X className="w-3 h-3" /></button>
            </span>
          ))}
          {selectedAges.map(a => (
            <span key={a} className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#FEF3C7] rounded-full text-xs font-semibold text-[#78350F]">
              {a}
              <button onClick={() => toggleAge(a)}><X className="w-3 h-3" /></button>
            </span>
          ))}
          {selectedGender && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#FEF3C7] rounded-full text-xs font-semibold text-[#78350F]">
              {selectedGender}
              <button onClick={() => setSelectedGender('')}><X className="w-3 h-3" /></button>
            </span>
          )}
          {locationQuery && (
            <span className="inline-flex items-center gap-1 px-2.5 py-1 bg-[#FEF3C7] rounded-full text-xs font-semibold text-[#78350F]">
              📍 {locationQuery}
              <button onClick={() => setLocationQuery('')}><X className="w-3 h-3" /></button>
            </span>
          )}
        </div>
      )}

      {/* Sort Indicator */}
      {!showFilters && hasActiveFilters && (
        <div className="px-4 py-1">
          <p className="text-xs text-[#92400E]/40">
            {filteredPets.length} ilan · {sortOptions.find(s => s.id === sortBy)?.label}
          </p>
        </div>
      )}

      {/* Pet Cards */}
      <div className="px-4 space-y-3 pt-2">
        {filteredPets.map((pet, index) => (
          <div
            key={pet.id}
            style={{ animationDelay: `${index * 40}ms` }}
            className="animate-in fade-in slide-in-from-bottom-2 duration-300"
          >
            <PetCard pet={pet} variant="vertical" onClick={() => setActiveTab('detail')} />
          </div>
        ))}

        {filteredPets.length === 0 && (
          <div className="flex flex-col items-center justify-center py-16">
            <div className="w-20 h-20 bg-[#FEF3C7] rounded-full flex items-center justify-center mb-4">
              <Search className="w-10 h-10 text-[#D97706]/40" />
            </div>
            <p className="text-[#78350F]/50 font-medium">Bu filtreye uygun ilan bulunamadı</p>
            <p className="text-xs text-[#92400E]/40 mt-1">Filtreleri değiştirerek tekrar deneyin</p>
            <button
              onClick={clearAllFilters}
              className="mt-4 px-6 py-2.5 bg-[#D97706] text-white font-[Quicksand] font-bold text-sm rounded-xl active:scale-[0.97] transition-transform"
            >
              Filtreleri Temizle
            </button>
          </div>
        )}
      </div>

      <BottomNav />
    </div>
  );
}
