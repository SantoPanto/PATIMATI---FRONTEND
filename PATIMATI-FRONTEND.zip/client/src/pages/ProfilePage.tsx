/*
 * Profile Page
 * Design: Warm amber header gradient, circular avatar, name, location badge,
 * 3 stat cards (adoptions, found, listings), menu list with icons.
 */

import { useApp } from '@/contexts/AppContext';
import { PawLogo } from '@/components/PawLogo';
import { PetCard } from '@/components/PetCard';
import { BottomNav } from '@/components/BottomNav';
import { PawPrint, MessageCircle, Bell, Heart, Settings, HelpCircle, FileText, MapPin, Plus } from 'lucide-react';

const menuItems = [
  { icon: FileText, label: 'İlanlarım', color: '#D97706', bgColor: '#FEF3C7' },
  { icon: MessageCircle, label: 'Mesajlarım', color: '#65A30D', bgColor: '#ECFCCB' },
  { icon: Bell, label: 'Bildirimler', color: '#D97706', bgColor: '#FEF3C7' },
  { icon: Heart, label: 'Kayıtlı Hayvanlar', color: '#DC2626', bgColor: '#FEE2E2' },
  { icon: Settings, label: 'Ayarlar', color: '#78350F', bgColor: '#F3E8D0' },
  { icon: HelpCircle, label: 'Yardım', color: '#92400E', bgColor: '#F3E8D0' },
];

export default function ProfilePage() {
  const { user, logout, userListings, chats, setActiveTab } = useApp();
  const myListings = userListings.filter(l => l.ownerId === user?.id);

  if (!user) return null;

  return (
    <div className="min-h-screen bg-[#FFFBF0] pb-24">
      {/* Header with gradient */}
      <div className="bg-gradient-to-b from-[#D97706] to-[#B45309] rounded-b-3xl px-4 pt-4 pb-16 relative overflow-hidden">
        {/* Decorative paw prints */}
        <svg className="absolute top-4 left-6 w-8 h-8 text-white/10" viewBox="0 0 24 24" fill="currentColor">
          <path d="M10 6c-1 0-2-.75-2-1.75S9 2.5 10 2.5s2 .75 2 1.75S11 6 10 6zM7 10c-1 0-2-.75-2-1.75S6 6.5 7 6.5s2 .75 2 1.75S8 10 7 10zM17 10c1 0 2-.75 2-1.75S18 6.5 17 6.5s-2 .75-2 1.75S16 10 17 10zM14 6c1 0 2-.75 2-1.75S15 2.5 14 2.5s-2 .75-2 1.75S13 6 14 6zM12 18c-3 0-6-2.5-6-7 0-2 1.5-3.5 3.5-3.5 1 0 2 .5 2.5 1.25.5-.75 1.5-1.25 2.5-1.25 2 0 3.5 1.5 3.5 3.5 0 4.5-3 7-6 7z" />
        </svg>
        <svg className="absolute top-12 right-8 w-6 h-6 text-white/8" viewBox="0 0 24 24" fill="currentColor">
          <path d="M10 6c-1 0-2-.75-2-1.75S9 2.5 10 2.5s2 .75 2 1.75S11 6 10 6zM7 10c-1 0-2-.75-2-1.75S6 6.5 7 6.5s2 .75 2 1.75S8 10 7 10zM17 10c1 0 2-.75 2-1.75S18 6.5 17 6.5s-2 .75-2 1.75S16 10 17 10zM14 6c1 0 2-.75 2-1.75S15 2.5 14 2.5s-2 .75-2 1.75S13 6 14 6zM12 18c-3 0-6-2.5-6-7 0-2 1.5-3.5 3.5-3.5 1 0 2 .5 2.5 1.25.5-.75 1.5-1.25 2.5-1.25 2 0 3.5 1.5 3.5 3.5 0 4.5-3 7-6 7z" />
        </svg>

        <div className="flex items-center justify-between mb-6">
          <PawLogo size="sm" className="[&>span]:text-white" />
          <button className="w-9 h-9 bg-white/20 rounded-full flex items-center justify-center">
            <svg className="w-4 h-4 text-white" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" /><path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
            </svg>
          </button>
        </div>

        <h1 className="font-[Quicksand] font-bold text-2xl text-white text-center">Profilim</h1>
      </div>

      {/* Avatar & Name */}
      <div className="flex flex-col items-center -mt-12 relative z-10">
        <div className="w-24 h-24 rounded-full border-4 border-white shadow-lg overflow-hidden bg-white">
          <img src={user.avatar} alt={user.name} className="w-full h-full object-cover" />
        </div>
        <h2 className="font-[Quicksand] font-bold text-2xl text-[#2D1B00] mt-3">{user.name}</h2>
        <div className="flex items-center gap-1.5 mt-1.5 px-3 py-1.5 bg-[#FEF3C7] rounded-full">
          <MapPin className="w-3.5 h-3.5 text-[#D97706]" />
          <span className="text-sm text-[#78350F] font-medium">{user.location}</span>
        </div>
      </div>

      {/* Stats */}
      <div className="px-4 mt-6 grid grid-cols-3 gap-3">
        <div className="bg-white rounded-2xl p-4 text-center shadow-sm shadow-amber-900/5">
          <div className="w-10 h-10 bg-[#FEF3C7] rounded-full flex items-center justify-center mx-auto mb-2">
            <PawPrint className="w-5 h-5 text-[#D97706]" />
          </div>
          <p className="font-[Quicksand] font-bold text-2xl text-[#D97706]">{user.stats.adoptions + myListings.filter(l => l.status === 'adoption').length}</p>
          <p className="text-xs text-[#78350F]/60 mt-0.5">Sahiplendirmeler</p>
        </div>
        <div className="bg-white rounded-2xl p-4 text-center shadow-sm shadow-amber-900/5">
          <div className="w-10 h-10 bg-[#ECFCCB] rounded-full flex items-center justify-center mx-auto mb-2">
            <svg className="w-5 h-5 text-[#65A30D]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="11" cy="11" r="8"/><path d="m21 21-4.35-4.35"/></svg>
          </div>
          <p className="font-[Quicksand] font-bold text-2xl text-[#65A30D]">{user.stats.foundPets}</p>
          <p className="text-xs text-[#78350F]/60 mt-0.5">Kayıp Hayvan Buldum</p>
        </div>
        <div className="bg-white rounded-2xl p-4 text-center shadow-sm shadow-amber-900/5">
          <div className="w-10 h-10 bg-[#F3E8D0] rounded-full flex items-center justify-center mx-auto mb-2">
            <FileText className="w-5 h-5 text-[#78350F]" />
          </div>
          <p className="font-[Quicksand] font-bold text-2xl text-[#78350F]">{user.stats.listings + myListings.length}</p>
          <p className="text-xs text-[#78350F]/60 mt-0.5">İlanlarım</p>
        </div>
      </div>

      {/* My Listings */}
      {myListings.length > 0 && (
        <div className="px-4 mt-6">
          <div className="flex items-center justify-between mb-3">
            <h3 className="font-[Quicksand] font-bold text-[#2D1B00]">İlanlarım</h3>
            <button
              onClick={() => setActiveTab('add')}
              className="flex items-center gap-1 text-sm text-[#D97706] font-semibold"
            >
              <Plus className="w-4 h-4" /> Yeni
            </button>
          </div>
          <div className="space-y-2">
            {myListings.slice(0, 3).map((pet) => (
              <PetCard key={pet.id} pet={pet} variant="horizontal" onClick={() => setActiveTab('detail')} />
            ))}
          </div>
        </div>
      )}

      {/* Menu */}
      <div className="px-4 mt-6 space-y-1">
        {menuItems.map((item) => {
          const Icon = item.icon;
          return (
            <button
              key={item.label}
              className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl hover:bg-white transition-colors active:scale-[0.99]"
            >
              <div
                className="w-9 h-9 rounded-full flex items-center justify-center"
                style={{ backgroundColor: item.bgColor }}
              >
                <Icon className="w-4 h-4" style={{ color: item.color }} />
              </div>
              <span className="flex-1 text-left text-[#2D1B00] font-medium">{item.label}</span>
              <svg className="w-4 h-4 text-[#92400E]/30" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
                <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
              </svg>
            </button>
          );
        })}

        {/* Logout */}
        <button
          onClick={logout}
          className="w-full flex items-center gap-3 px-4 py-3.5 rounded-xl hover:bg-red-50 transition-colors mt-4"
        >
          <div className="w-9 h-9 rounded-full bg-red-100 flex items-center justify-center">
            <svg className="w-4 h-4 text-red-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4" /><polyline points="16 17 21 12 16 7" /><line x1="21" y1="12" x2="9" y2="12" /></svg>
          </div>
          <span className="flex-1 text-left text-red-500 font-medium">Çıkış Yap</span>
        </button>
      </div>

      <BottomNav />
    </div>
  );
}
