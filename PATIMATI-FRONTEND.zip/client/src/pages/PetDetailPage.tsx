/*
 * Pet Detail Page
 * Design: Large hero image with back/share/heart overlays, status badge,
 * pet name, breed, age/gender/color info grid, location/contact/description
 * sections, health tags (Aşılı, Kısırlaştırılmış, Evcil), sticky bottom action bar.
 * Dynamic: pulls pet data from userListings context.
 */

import { useApp } from '@/contexts/AppContext';
import { BottomNav } from '@/components/BottomNav';
import { MOCK_PETS } from '@/const';
import { Heart, Share2, MapPin, Phone, FileText, Shield, Scissors, Home, PawPrint, MessageCircle } from 'lucide-react';

export default function PetDetailPage() {
  const { setActiveTab, userListings, startChat } = useApp();

  // Get pet from user-generated listings, fallback to demo
  const pets = userListings.length > 0 ? userListings : MOCK_PETS;
  const pet = pets[0]; // First pet as default

  if (!pet) return null;

  const statusLabel = pet.status === 'lost' ? 'Kayıp Hayvan' : pet.status === 'found' ? 'Bulundu' : 'Sahiplenilmeyi Bekliyor';
  const statusColor = pet.status === 'lost' ? '#DC2626' : pet.status === 'found' ? '#65A30D' : '#D97706';
  const statusBg = pet.status === 'lost' ? '#DC2626/10' : pet.status === 'found' ? '#65A30D/10' : '#D97706/10';

  const handleMessage = () => {
    const chat = startChat(pet.ownerName, '', pet.name + ' hakkında');
    setActiveTab('chat');
  };

  return (
    <div className="min-h-screen bg-[#FFFBF0] pb-32">
      {/* Hero Image */}
      <div className="relative">
        <img src={pet.image} alt={pet.name} className="w-full h-72 object-cover" />
        <div className="absolute inset-0 bg-gradient-to-t from-black/30 to-transparent" />
        <div className="absolute top-4 left-4 right-4 flex items-center justify-between">
          <button
            onClick={() => setActiveTab('listings')}
            className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-sm active:scale-95 transition-transform"
          >
            <svg className="w-5 h-5 text-[#78350F]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </button>
          <div className="flex gap-2">
            <button className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-sm active:scale-95 transition-transform">
              <Heart className="w-5 h-5 text-[#D97706]" />
            </button>
            <button className="w-10 h-10 bg-white/90 rounded-full flex items-center justify-center shadow-sm active:scale-95 transition-transform">
              <Share2 className="w-5 h-5 text-[#78350F]" />
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="px-4 -mt-6 relative z-10">
        <div className="bg-white rounded-2xl shadow-md shadow-amber-900/5 p-5">
          {/* Status Badge */}
          <div className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-full text-sm font-semibold mb-3"
               style={{ backgroundColor: statusBg, color: statusColor }}>
            <PawPrint className="w-4 h-4" />
            {statusLabel}
          </div>

          {/* Name & Breed */}
          <h1 className="font-[Quicksand] font-bold text-3xl text-[#2D1B00]">{pet.name}</h1>
          <p className="text-lg text-[#78350F]/60 mt-0.5">{pet.breed}</p>

          {/* Info Grid */}
          <div className="grid grid-cols-3 gap-3 mt-5">
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-[#D97706]" viewBox="0 0 24 24" fill="currentColor"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"/><line x1="16" y1="2" x2="16" y2="6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/><line x1="8" y1="2" x2="8" y2="6" stroke="currentColor" strokeWidth="2" strokeLinecap="round"/><line x1="3" y1="10" x2="21" y2="10" stroke="currentColor" strokeWidth="2"/></svg>
              <span className="text-sm text-[#2D1B00] font-medium">{pet.age}</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-[#D97706]" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M8 12h8M12 8v8"/></svg>
              <span className="text-sm text-[#2D1B00] font-medium">{pet.gender === 'male' ? 'Erkek' : 'Dişi'}</span>
            </div>
            <div className="flex items-center gap-2">
              <svg className="w-5 h-5 text-[#D97706]" viewBox="0 0 24 24" fill="currentColor"><circle cx="12" cy="12" r="10"/></svg>
              <span className="text-sm text-[#2D1B00] font-medium">{pet.color}</span>
            </div>
          </div>

          {/* Info Sections */}
          <div className="space-y-3 mt-5">
            <div className="flex items-center gap-3 p-3 bg-[#FFFBF0] rounded-xl">
              <MapPin className="w-5 h-5 text-[#D97706] flex-shrink-0" />
              <span className="text-sm text-[#2D1B00]">{pet.location}</span>
              <span className="text-xs text-[#92400E]/40 ml-auto">{pet.distance}</span>
            </div>
            <div className="flex items-center gap-3 p-3 bg-[#FFFBF0] rounded-xl">
              <Phone className="w-5 h-5 text-[#D97706] flex-shrink-0" />
              <span className="text-sm text-[#2D1B00]">İletişim: {pet.contact}</span>
            </div>
            <div className="p-3 bg-[#FFFBF0] rounded-xl">
              <div className="flex items-start gap-3">
                <FileText className="w-5 h-5 text-[#D97706] flex-shrink-0 mt-0.5" />
                <p className="text-sm text-[#2D1B00] leading-relaxed">{pet.description}</p>
              </div>
              <div className="flex items-center gap-2 mt-3 pt-3 border-t border-[#F3E8D0]">
                <span className="text-xs text-[#92400E]/40">İlan sahibi:</span>
                <span className="text-sm font-semibold text-[#2D1B00]">{pet.ownerName}</span>
              </div>
            </div>
          </div>

          {/* Health Tags */}
          <div className="flex flex-wrap gap-2 mt-5">
            {pet.vaccinated && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#65A30D]/10 text-[#65A30D] rounded-full text-sm font-medium">
                <Shield className="w-3.5 h-3.5" />
                Aşılı
              </span>
            )}
            {pet.neutered && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#D97706]/10 text-[#D97706] rounded-full text-sm font-medium">
                <Scissors className="w-3.5 h-3.5" />
                Kısırlaştırılmış
              </span>
            )}
            {pet.houseTrained && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#78350F]/10 text-[#78350F] rounded-full text-sm font-medium">
                <Home className="w-3.5 h-3.5" />
                Evcil
              </span>
            )}
            {!pet.vaccinated && !pet.neutered && !pet.houseTrained && (
              <span className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-[#92400E]/10 text-[#92400E]/60 rounded-full text-sm font-medium">
                Bilgiler eksik — ilan sahibine sorun
              </span>
            )}
          </div>
        </div>
      </div>

      {/* Sticky Bottom Actions */}
      <div className="fixed bottom-0 left-0 right-0 z-50 bg-white border-t border-[#F3E8D0] px-4 py-3 pb-[calc(env(safe-area-inset-bottom)+12px)]">
        <div className="max-w-lg mx-auto flex gap-3">
          <button
            onClick={handleMessage}
            className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl border-2 border-[#D97706] text-[#D97706] font-[Quicksand] font-bold active:scale-[0.97] transition-transform"
          >
            <MessageCircle className="w-5 h-5" />
            Mesaj Gönder
          </button>
          <button className="flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl bg-[#D97706] text-white font-[Quicksand] font-bold shadow-md shadow-amber-600/20 active:scale-[0.97] transition-transform">
            <PawPrint className="w-5 h-5" />
            {pet.status === 'adoption' ? 'Sahiplen' : 'İletişime Geç'}
          </button>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
