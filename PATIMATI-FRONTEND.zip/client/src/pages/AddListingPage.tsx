/*
 * Add Listing Page
 * Design: Header "Yeni İlan Ekle", photo upload area with dashed border,
 * animal info form (Tür, Cins, Yaş, Cinsiyet), status toggle (Sahiplendirme/Kayıp-Bulunan),
 * location input, description textarea, publish button.
 * User-generated: listings are created dynamically and added to the global state.
 */

import { useApp } from '@/contexts/AppContext';
import { PawLogo } from '@/components/PawLogo';
import { PattyButton } from '@/components/PattyButton';
import { Camera, MapPin, Send, PawPrint, Search, X, Upload, CheckCircle2 } from 'lucide-react';
import { useState, useRef } from 'react';
import { toast } from 'sonner';

type ListingType = 'adoption' | 'lost';
type PetType = 'cat' | 'dog' | '';
type PetGender = 'male' | 'female' | '';

const BREEDS: Record<string, string[]> = {
  cat: ['Tekir Kedi', 'Persian', 'Van Kedisi', 'Sokak Kedisi', 'British Shorthair', 'Scottish Fold'],
  dog: ['Golden Retriever', 'Labrador', 'Kangal', 'Sokak Köpeği', 'Husky', 'German Shepherd', 'Jack Russell'],
};

const AGE_OPTIONS = ['0 - 1 yaş', '1 - 2 yaş', '2 - 5 yaş', '5 yaş ve üzeri'];

export default function AddListingPage() {
  const { setActiveTab, user, addListing } = useApp();
  const [listingType, setListingType] = useState<ListingType>('adoption');
  const [petType, setPetType] = useState<PetType>('');
  const [breed, setBreed] = useState('');
  const [age, setAge] = useState('');
  const [gender, setGender] = useState<PetGender>('');
  const [color, setColor] = useState('');
  const [location, setLocation] = useState('');
  const [description, setDescription] = useState('');
  const [uploadedImages, setUploadedImages] = useState<string[]>([]);
  const [showSuccess, setShowSuccess] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files;
    if (!files) return;

    Array.from(files).forEach(file => {
      if (uploadedImages.length >= 5) return;
      const reader = new FileReader();
      reader.onload = (ev) => {
        const url = ev.target?.result as string;
        setUploadedImages(prev => [...prev, url]);
      };
      reader.readAsDataURL(file);
    });

    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  const removeImage = (index: number) => {
    setUploadedImages(prev => prev.filter((_, i) => i !== index));
  };

  const handlePublish = () => {
    if (!user) return;

    if (uploadedImages.length === 0) {
      toast.error('En az 1 fotoğraf ekleyin');
      return;
    }
    if (!petType) {
      toast.error('Hayvan türünü seçin');
      return;
    }
    if (!breed) {
      toast.error('Cins bilgisi girin');
      return;
    }
    if (!location) {
      toast.error('Konum bilgisi girin');
      return;
    }

    const newListing = {
      id: `listing-${Date.now()}`,
      name: breed,
      type: petType as 'cat' | 'dog',
      breed,
      age: age || 'Bilinmiyor',
      gender: (gender || 'male') as 'male' | 'female',
      color: color || 'Belirtilmedi',
      location,
      distance: '0 km',
      image: uploadedImages[0],
      status: listingType,
      vaccinated: false,
      neutered: false,
      houseTrained: false,
      description: description || 'Açıklama yok',
      contact: 'İletişim bilgisi yok',
      createdAt: new Date().toISOString().split('T')[0],
      ownerId: user.id,
      ownerName: user.name,
    };

    addListing(newListing);
    setShowSuccess(true);
    setTimeout(() => {
      setActiveTab('listings');
      setShowSuccess(false);
    }, 2000);
  };

  if (showSuccess) {
    return (
      <div className="min-h-screen bg-[#FFFBF0] flex items-center justify-center px-4">
        <div className="text-center space-y-4 animate-in zoom-in duration-300">
          <div className="w-20 h-20 bg-[#65A30D]/10 rounded-full flex items-center justify-center mx-auto">
            <CheckCircle2 className="w-10 h-10 text-[#65A30D]" />
          </div>
          <h2 className="font-[Quicksand] font-bold text-xl text-[#2D1B00]">İlan Yayınlandı!</h2>
          <p className="text-sm text-[#78350F]/60">İlanınız başarıyla oluşturuldu</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#FFFBF0] pb-8">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-lg px-4 pt-4 pb-3 border-b border-[#F3E8D0]">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveTab('home')}
            className="w-10 h-10 rounded-full bg-[#FEF3C7] flex items-center justify-center active:scale-95 transition-transform"
          >
            <svg className="w-5 h-5 text-[#78350F]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </button>
          <h1 className="font-[Quicksand] font-bold text-xl text-[#2D1B00]">Yeni İlan Ekle</h1>
          <div className="w-10" />
        </div>
      </header>

      <div className="px-4 py-5 space-y-5">
        {/* Photo Upload */}
        <div className="bg-white rounded-2xl p-5 shadow-sm shadow-amber-900/5">
          <h3 className="font-[Quicksand] font-bold text-sm text-[#2D1B00] mb-3 flex items-center gap-2">
            <Camera className="w-4 h-4 text-[#D97706]" />
            Fotoğraflar ({uploadedImages.length}/5)
          </h3>

          {/* Preview Grid */}
          {uploadedImages.length > 0 && (
            <div className="grid grid-cols-3 gap-2 mb-3">
              {uploadedImages.map((img, i) => (
                <div key={i} className="relative rounded-xl overflow-hidden aspect-square">
                  <img src={img} alt={`Fotoğraf ${i + 1}`} className="w-full h-full object-cover" />
                  <button
                    onClick={() => removeImage(i)}
                    className="absolute top-1 right-1 w-6 h-6 bg-red-500 rounded-full flex items-center justify-center"
                  >
                    <X className="w-3 h-3 text-white" />
                  </button>
                </div>
              ))}
            </div>
          )}

          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            multiple
            className="hidden"
            onChange={handleFileSelect}
          />
          <button
            onClick={() => fileInputRef.current?.click()}
            disabled={uploadedImages.length >= 5}
            className={`w-full border-2 border-dashed rounded-xl p-4 text-center transition-colors ${
              uploadedImages.length >= 5
                ? 'border-[#F3E8D0] bg-[#FFFBF0] cursor-not-allowed'
                : 'border-[#D97706]/30 hover:border-[#D97706]/60 active:scale-[0.98]'
            }`}
          >
            <Upload className="w-6 h-6 text-[#D97706] mx-auto mb-1" />
            <p className="text-sm font-semibold text-[#78350F]">Fotoğraf Yükle</p>
            <p className="text-xs text-[#92400E]/40 mt-0.5">Cihazından seç veya fotoğraf çek</p>
          </button>
        </div>

        {/* Status Toggle */}
        <div className="bg-white rounded-2xl p-5 shadow-sm shadow-amber-900/5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-[#FEF3C7] rounded-lg flex items-center justify-center">
              <PawPrint className="w-4 h-4 text-[#D97706]" />
            </div>
            <h3 className="font-[Quicksand] font-bold text-[#2D1B00]">İlan Durumu</h3>
          </div>
          <div className="flex gap-3">
            <button
              onClick={() => setListingType('adoption')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-[Quicksand] font-bold text-sm transition-all duration-200 ${
                listingType === 'adoption'
                  ? 'bg-[#D97706] text-white shadow-md shadow-amber-600/20'
                  : 'bg-[#FFFBF0] text-[#78350F]/60 border border-[#F3E8D0]'
              }`}
            >
              <PawPrint className="w-4 h-4" />
              Sahiplendirme
            </button>
            <button
              onClick={() => setListingType('lost')}
              className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl font-[Quicksand] font-bold text-sm transition-all duration-200 ${
                listingType === 'lost'
                  ? 'bg-[#DC2626] text-white shadow-md shadow-red-600/20'
                  : 'bg-[#FFFBF0] text-[#78350F]/60 border border-[#F3E8D0]'
              }`}
            >
              <Search className="w-4 h-4" />
              Kayıp/Bulunan
            </button>
          </div>
        </div>

        {/* Animal Info */}
        <div className="bg-white rounded-2xl p-5 shadow-sm shadow-amber-900/5">
          <div className="flex items-center gap-2 mb-4">
            <div className="w-8 h-8 bg-[#FEF3C7] rounded-lg flex items-center justify-center">
              <PawPrint className="w-4 h-4 text-[#D97706]" />
            </div>
            <h3 className="font-[Quicksand] font-bold text-[#2D1B00]">Hayvan Bilgileri</h3>
          </div>

          <div className="space-y-3">
            {/* Type */}
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-[#78350F]">Tür *</label>
              <div className="flex gap-2">
                <button
                  onClick={() => { setPetType('cat'); setBreed(''); }}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    petType === 'cat' ? 'bg-[#D97706] text-white' : 'bg-[#FFFBF0] text-[#92400E]/60 border border-[#F3E8D0]'
                  }`}
                >
                  Kedi
                </button>
                <button
                  onClick={() => { setPetType('dog'); setBreed(''); }}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    petType === 'dog' ? 'bg-[#D97706] text-white' : 'bg-[#FFFBF0] text-[#92400E]/60 border border-[#F3E8D0]'
                  }`}
                >
                  Köpek
                </button>
              </div>
            </div>

            {/* Breed */}
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-[#78350F]">Cins *</label>
              <select
                value={breed}
                onChange={(e) => setBreed(e.target.value)}
                disabled={!petType}
                className="w-full px-4 py-2.5 rounded-xl border border-[#F3E8D0] bg-[#FFFBF0] text-sm text-[#2D1B00] focus:border-[#D97706] focus:outline-none disabled:opacity-50"
              >
                <option value="">Cins seçiniz</option>
                {petType && BREEDS[petType]?.map(b => (
                  <option key={b} value={b}>{b}</option>
                ))}
              </select>
            </div>

            {/* Age */}
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-[#78350F]">Yaş</label>
              <div className="flex gap-2 flex-wrap">
                {AGE_OPTIONS.map(a => (
                  <button
                    key={a}
                    onClick={() => setAge(age === a ? '' : a)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                      age === a ? 'bg-[#D97706] text-white' : 'bg-[#FFFBF0] text-[#92400E]/60 border border-[#F3E8D0]'
                    }`}
                  >
                    {a}
                  </button>
                ))}
              </div>
            </div>

            {/* Gender */}
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-[#78350F]">Cinsiyet</label>
              <div className="flex gap-2">
                <button
                  onClick={() => setGender(gender === 'male' ? '' : 'male')}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    gender === 'male' ? 'bg-[#3B82F6] text-white' : 'bg-[#FFFBF0] text-[#92400E]/60 border border-[#F3E8D0]'
                  }`}
                >
                  Erkek
                </button>
                <button
                  onClick={() => setGender(gender === 'female' ? '' : 'female')}
                  className={`flex-1 py-2.5 rounded-xl text-sm font-semibold transition-all ${
                    gender === 'female' ? 'bg-[#EC4899] text-white' : 'bg-[#FFFBF0] text-[#92400E]/60 border border-[#F3E8D0]'
                  }`}
                >
                  Dişi
                </button>
              </div>
            </div>

            {/* Color */}
            <div className="space-y-1.5">
              <label className="text-sm font-medium text-[#78350F]">Renk</label>
              <input
                type="text"
                value={color}
                onChange={(e) => setColor(e.target.value)}
                placeholder="Örn: Beyaz, Gri Tekir, Altın Sarısı"
                className="w-full px-4 py-2.5 rounded-xl border border-[#F3E8D0] bg-[#FFFBF0] text-sm text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none"
              />
            </div>
          </div>
        </div>

        {/* Location */}
        <div className="bg-white rounded-2xl p-5 shadow-sm shadow-amber-900/5">
          <label className="text-sm font-medium text-[#78350F] mb-2 block">Konum *</label>
          <div className="relative">
            <MapPin className="absolute right-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D97706]" />
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="Örn: Kadıköy, İstanbul"
              className="w-full px-4 py-3.5 pr-11 rounded-xl border border-[#F3E8D0] bg-[#FFFBF0] text-sm text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors"
            />
          </div>
        </div>

        {/* Description */}
        <div className="bg-white rounded-2xl p-5 shadow-sm shadow-amber-900/5">
          <label className="text-sm font-medium text-[#78350F] mb-2 block">Açıklama</label>
          <textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            placeholder="Hayvan hakkında bilgi verin..."
            rows={4}
            maxLength={1000}
            className="w-full px-4 py-3 rounded-xl border border-[#F3E8D0] bg-[#FFFBF0] text-sm text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors resize-none"
          />
          <p className="text-xs text-[#92400E]/40 text-right mt-1">{description.length}/1000</p>
        </div>

        {/* Publish Button */}
        <PattyButton
          variant="primary"
          size="lg"
          fullWidth
          icon={<Send className="w-5 h-5" />}
          onClick={handlePublish}
        >
          İlanı Yayınla
        </PattyButton>

        <p className="text-center text-xs text-[#92400E]/30 pb-4">
          İlanınız yayınlandıktan sonra tüm kullanıcılara görünür olacaktır
        </p>
      </div>
    </div>
  );
}
