/*
 * Chat Page
 * Design: Header with "Sohbetler" title, search bar, conversation list
 * with avatars, pet context, last message preview, time, and unread badges.
 * User-generated: chats and messages are created dynamically by users.
 */

import { useApp } from '@/contexts/AppContext';
import { PawLogo } from '@/components/PawLogo';
import { BottomNav } from '@/components/BottomNav';
import { Search, MessageCircle, PawPrint, Send } from 'lucide-react';
import { useState } from 'react';

export default function ChatPage() {
  const { chats, messages, sendMessage, startChat } = useApp();
  const [searchQuery, setSearchQuery] = useState('');
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [newMessage, setNewMessage] = useState('');
  const [newChatName, setNewChatName] = useState('');
  const [showNewChat, setShowNewChat] = useState(false);

  const filteredChats = chats.filter(c =>
    c.participantName.toLowerCase().includes(searchQuery.toLowerCase()) ||
    c.petName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const chatMessages = messages.filter(m => m.chatId === activeChatId);
  const activeChat = chats.find(c => c.id === activeChatId);

  const handleSend = () => {
    if (!newMessage.trim() || !activeChatId) return;
    sendMessage(activeChatId, newMessage.trim());
    setNewMessage('');
  };

  const handleStartChat = () => {
    if (!newChatName.trim()) return;
    const chat = startChat(newChatName.trim(), '', '');
    setActiveChatId(chat.id);
    setShowNewChat(false);
    setNewChatName('');
  };

  return (
    <div className="min-h-screen bg-[#FFFBF0] pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#FFFBF0]/95 backdrop-blur-lg px-4 pt-4 pb-3">
        <div className="flex items-center justify-between mb-3">
          <PawLogo size="sm" />
          <div className="flex items-center gap-2">
            <button
              onClick={() => setShowNewChat(!showNewChat)}
              className="w-9 h-9 bg-[#D97706] rounded-full flex items-center justify-center shadow-sm active:scale-95 transition-transform"
            >
              <Send className="w-4 h-4 text-white" />
            </button>
            <button className="w-9 h-9 bg-white rounded-full flex items-center justify-center shadow-sm">
              <MessageCircle className="w-4 h-4 text-[#78350F]" />
            </button>
          </div>
        </div>
        <h1 className="font-[Quicksand] font-bold text-3xl text-[#2D1B00]">Sohbetler</h1>
      </header>

      {/* New Chat Input */}
      {showNewChat && (
        <div className="px-4 py-3 animate-in slide-in-from-top-2 duration-200">
          <div className="bg-white rounded-2xl p-4 shadow-md shadow-amber-900/5">
            <p className="text-sm font-semibold text-[#2D1B00] mb-2">Yeni Sohbet Başlat</p>
            <div className="flex gap-2">
              <input
                type="text"
                value={newChatName}
                onChange={(e) => setNewChatName(e.target.value)}
                placeholder="Kişi adı..."
                className="flex-1 px-4 py-2.5 rounded-xl border-2 border-[#F3E8D0] bg-[#FFFBF0] text-sm text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none"
              />
              <button
                onClick={handleStartChat}
                className="px-4 py-2.5 bg-[#D97706] text-white rounded-xl font-[Quicksand] font-bold text-sm active:scale-95 transition-transform"
              >
                Başlat
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Search */}
      <div className="px-4 py-2">
        <div className="relative">
          <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-[#92400E]/40" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Sohbet ara..."
            className="w-full px-4 py-3 pl-10 rounded-xl border border-[#F3E8D0] bg-white text-sm text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors"
          />
        </div>
      </div>

      {/* Chat List or Active Chat */}
      {!activeChatId ? (
        <div className="px-4 space-y-0">
          {filteredChats.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16">
              <div className="w-20 h-20 bg-[#FEF3C7] rounded-full flex items-center justify-center mb-4">
                <MessageCircle className="w-10 h-10 text-[#D97706]/40" />
              </div>
              <p className="text-sm text-[#92400E]/50 font-medium">Henüz sohbet yok</p>
              <p className="text-xs text-[#92400E]/40 mt-1">Yeni sohbet başlatmak için + butonuna tıkla</p>
            </div>
          ) : (
            filteredChats.map((chat, index) => (
              <div
                key={chat.id}
                onClick={() => setActiveChatId(chat.id)}
                className="flex items-center gap-3 py-4 border-b border-[#F3E8D0]/60 cursor-pointer active:bg-[#FEF3C7]/30 transition-colors rounded-xl px-2"
                style={{ animationDelay: `${index * 40}ms` }}
              >
                {/* Avatar */}
                <div className="relative flex-shrink-0">
                  {chat.participantAvatar ? (
                    <img src={chat.participantAvatar} alt={chat.participantName} className="w-14 h-14 rounded-full object-cover" />
                  ) : (
                    <div className="w-14 h-14 rounded-full bg-[#FEF3C7] flex items-center justify-center">
                      <span className="text-lg font-bold text-[#D97706]">{chat.participantName.charAt(0)}</span>
                    </div>
                  )}
                  <div className="absolute -bottom-0.5 -right-0.5 w-5 h-5 bg-[#D97706] rounded-full flex items-center justify-center border-2 border-[#FFFBF0]">
                    <PawPrint className="w-2.5 h-2.5 text-white" />
                  </div>
                </div>

                {/* Content */}
                <div className="flex-1 min-w-0">
                  <div className="flex items-center justify-between">
                    <h3 className="font-[Quicksand] font-bold text-[#2D1B00]">{chat.participantName}</h3>
                    <span className="text-xs text-[#92400E]/50">{chat.time}</span>
                  </div>
                  {chat.petName && (
                    <div className="flex items-center gap-1 mt-0.5">
                      <PawPrint className="w-3 h-3 text-[#D97706]" />
                      <span className="text-sm text-[#D97706]">{chat.petName}</span>
                    </div>
                  )}
                  <p className="text-sm text-[#78350F]/50 mt-0.5 truncate">{chat.lastMessage}</p>
                </div>

                {/* Unread Badge */}
                {chat.unreadCount > 0 && (
                  <div className="flex-shrink-0 w-6 h-6 bg-[#D97706] rounded-full flex items-center justify-center">
                    <span className="text-[10px] font-bold text-white">{chat.unreadCount}</span>
                  </div>
                )}
              </div>
            ))
          )}
        </div>
      ) : (
        /* Active Chat View */
        <div className="px-4 flex flex-col" style={{ height: 'calc(100vh - 280px)' }}>
          {/* Chat Header */}
          <div className="flex items-center gap-3 py-3 border-b border-[#F3E8D0]/60 mb-3">
            <button
              onClick={() => setActiveChatId(null)}
              className="w-9 h-9 rounded-full bg-[#FEF3C7] flex items-center justify-center active:scale-95 transition-transform"
            >
              <svg className="w-4 h-4 text-[#78350F]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
              </svg>
            </button>
            <div className="flex-1">
              <h3 className="font-[Quicksand] font-bold text-sm text-[#2D1B00]">{activeChat?.participantName}</h3>
              {activeChat?.petName && (
                <p className="text-xs text-[#D97706] flex items-center gap-1">
                  <PawPrint className="w-3 h-3" /> {activeChat.petName}
                </p>
              )}
            </div>
          </div>

          {/* Messages */}
          <div className="flex-1 overflow-y-auto space-y-3 mb-3">
            {chatMessages.length === 0 && (
              <div className="text-center py-8">
                <PawPrint className="w-8 h-8 text-[#D97706]/20 mx-auto mb-2" />
                <p className="text-sm text-[#92400E]/40">Henüz mesaj yok. İlk mesajı gönder!</p>
              </div>
            )}
            {chatMessages.map((msg) => (
              <div key={msg.id} className="flex justify-end">
                <div className="max-w-[80%] bg-[#D97706] text-white rounded-2xl rounded-br-sm px-4 py-2.5 shadow-sm">
                  <p className="text-sm">{msg.text}</p>
                  <p className="text-[10px] text-white/60 text-right mt-1">{msg.time}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Message Input */}
          <div className="flex gap-2">
            <input
              type="text"
              value={newMessage}
              onChange={(e) => setNewMessage(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Mesaj yaz..."
              className="flex-1 px-4 py-3 rounded-xl border-2 border-[#F3E8D0] bg-white text-sm text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none"
            />
            <button
              onClick={handleSend}
              disabled={!newMessage.trim()}
              className="w-12 h-12 bg-[#D97706] rounded-xl flex items-center justify-center active:scale-95 transition-transform disabled:opacity-40"
            >
              <Send className="w-5 h-5 text-white" />
            </button>
          </div>
        </div>
      )}

      <BottomNav />
    </div>
  );
}
