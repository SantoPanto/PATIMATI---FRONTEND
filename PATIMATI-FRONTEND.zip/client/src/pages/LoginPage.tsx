/*
 * Login Page
 * Design: Warm cream background, cute illustrated pet logo, email/password inputs,
 * Giriş Yap (primary amber), Hesap Oluştur (outline), Şifremi Unuttum link.
 */

import { useApp } from '@/contexts/AppContext';
import { PawLogo } from '@/components/PawLogo';
import { PattyButton } from '@/components/PattyButton';
import { Mail, Lock, Eye, EyeOff, PawPrint } from 'lucide-react';
import { useState } from 'react';

export default function LoginPage() {
  const { login } = useApp();
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [isRegister, setIsRegister] = useState(false);
  const [name, setName] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    login(email, password);
  };

  return (
    <div className="min-h-screen bg-[#FFFBF0] flex flex-col items-center justify-center px-6 py-8">
      {/* Decorative paw prints */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <svg className="absolute top-16 left-8 w-8 h-8 text-[#D97706]/10" viewBox="0 0 24 24" fill="currentColor">
          <path d="M10 6c-1 0-2-.75-2-1.75S9 2.5 10 2.5s2 .75 2 1.75S11 6 10 6zM7 10c-1 0-2-.75-2-1.75S6 6.5 7 6.5s2 .75 2 1.75S8 10 7 10zM17 10c1 0 2-.75 2-1.75S18 6.5 17 6.5s-2 .75-2 1.75S16 10 17 10zM14 6c1 0 2-.75 2-1.75S15 2.5 14 2.5s-2 .75-2 1.75S13 6 14 6zM12 18c-3 0-6-2.5-6-7 0-2 1.5-3.5 3.5-3.5 1 0 2 .5 2.5 1.25.5-.75 1.5-1.25 2.5-1.25 2 0 3.5 1.5 3.5 3.5 0 4.5-3 7-6 7z" />
        </svg>
        <svg className="absolute top-32 right-6 w-6 h-6 text-[#D97706]/8" viewBox="0 0 24 24" fill="currentColor">
          <path d="M10 6c-1 0-2-.75-2-1.75S9 2.5 10 2.5s2 .75 2 1.75S11 6 10 6zM7 10c-1 0-2-.75-2-1.75S6 6.5 7 6.5s2 .75 2 1.75S8 10 7 10zM17 10c1 0 2-.75 2-1.75S18 6.5 17 6.5s-2 .75-2 1.75S16 10 17 10zM14 6c1 0 2-.75 2-1.75S15 2.5 14 2.5s-2 .75-2 1.75S13 6 14 6zM12 18c-3 0-6-2.5-6-7 0-2 1.5-3.5 3.5-3.5 1 0 2 .5 2.5 1.25.5-.75 1.5-1.25 2.5-1.25 2 0 3.5 1.5 3.5 3.5 0 4.5-3 7-6 7z" />
        </svg>
        <svg className="absolute bottom-24 left-12 w-10 h-10 text-[#D97706]/6 rotate-12" viewBox="0 0 24 24" fill="currentColor">
          <path d="M10 6c-1 0-2-.75-2-1.75S9 2.5 10 2.5s2 .75 2 1.75S11 6 10 6zM7 10c-1 0-2-.75-2-1.75S6 6.5 7 6.5s2 .75 2 1.75S8 10 7 10zM17 10c1 0 2-.75 2-1.75S18 6.5 17 6.5s-2 .75-2 1.75S16 10 17 10zM14 6c1 0 2-.75 2-1.75S15 2.5 14 2.5s-2 .75-2 1.75S13 6 14 6zM12 18c-3 0-6-2.5-6-7 0-2 1.5-3.5 3.5-3.5 1 0 2 .5 2.5 1.25.5-.75 1.5-1.25 2.5-1.25 2 0 3.5 1.5 3.5 3.5 0 4.5-3 7-6 7z" />
        </svg>
      </div>

      {/* Logo */}
      <div className="relative z-10 mb-8">
        <div className="flex items-center justify-center mb-2">
          <div className="relative">
            <div className="w-24 h-24 bg-[#FEF3C7] rounded-full flex items-center justify-center">
              <svg viewBox="0 0 48 48" className="w-14 h-14 text-[#D97706]" fill="currentColor">
                <path d="M10 14c-2 0-4-1.5-4-3.5S8 7 10 7s4 1.5 4 3.5S12 14 10 14zM18 8c-2 0-4-1.5-4-3.5S16 1 18 1s4 1.5 4 3.5S20 8 18 8zM30 8c2 0 4-1.5 4-3.5S32 1 30 1s-4 1.5-4 3.5S28 8 30 8zM38 14c2 0 4-1.5 4-3.5S40 7 38 7s-4 1.5-4 3.5S36 14 38 14zM24 38c-6 0-12-5-12-14 0-4 3-7 7-7 2 0 4 1 5 2.5 1-1.5 3-2.5 5-2.5 4 0 7 3 7 7 0 9-6 14-12 14z" />
              </svg>
            </div>
          </div>
        </div>
        <PawLogo size="lg" className="justify-center mt-4" />
        <p className="text-center text-[#78350F]/60 mt-2 text-sm">Patili dostlar için daha iyi bir dünya</p>
      </div>

      {/* Form */}
      <form onSubmit={handleSubmit} className="relative z-10 w-full max-w-sm space-y-4">
        {isRegister && (
          <div>
            <label className="text-sm font-semibold text-[#2D1B00] mb-1.5 block font-[Quicksand]">Ad Soyad</label>
            <div className="relative">
              <input
                type="text"
                value={name}
                onChange={(e) => setName(e.target.value)}
                placeholder="Adınızı girin"
                className="w-full px-4 py-3.5 pl-11 rounded-xl border-2 border-[#F3E8D0] bg-white text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors"
              />
            </div>
          </div>
        )}

        <div>
          <label className="text-sm font-semibold text-[#2D1B00] mb-1.5 block font-[Quicksand]">E-posta</label>
          <div className="relative">
            <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#92400E]/40" />
            <input
              type="email"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="E-posta adresinizi girin"
              className="w-full px-4 py-3.5 pl-11 rounded-xl border-2 border-[#F3E8D0] bg-white text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors"
            />
          </div>
        </div>

        <div>
          <label className="text-sm font-semibold text-[#2D1B00] mb-1.5 block font-[Quicksand]">Şifre</label>
          <div className="relative">
            <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-5 h-5 text-[#92400E]/40" />
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Şifrenizi girin"
              className="w-full px-4 py-3.5 pl-11 pr-11 rounded-xl border-2 border-[#F3E8D0] bg-white text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3.5 top-1/2 -translate-y-1/2 text-[#92400E]/40"
            >
              {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
            </button>
          </div>
        </div>

        <PattyButton type="submit" variant="primary" size="lg" fullWidth icon={<PawPrint className="w-5 h-5" />}>
          {isRegister ? 'Hesap Oluştur' : 'Giriş Yap'}
        </PattyButton>

        {!isRegister && (
          <button
            type="button"
            onClick={() => setIsRegister(true)}
            className="w-full text-center text-sm text-[#78350F]/60 hover:text-[#D97706] transition-colors font-medium"
          >
            Hesabınız yok mu? <span className="text-[#D97706] font-semibold">Hesap Oluştur</span>
          </button>
        )}

        {isRegister && (
          <button
            type="button"
            onClick={() => setIsRegister(false)}
            className="w-full text-center text-sm text-[#78350F]/60 hover:text-[#D97706] transition-colors font-medium"
          >
            Zaten hesabınız var mı? <span className="text-[#D97706] font-semibold">Giriş Yap</span>
          </button>
        )}

        {!isRegister && (
          <button type="button" className="w-full text-center text-sm text-[#D97706] underline underline-offset-2 hover:text-[#B45309] transition-colors">
            Şifremi Unuttum
          </button>
        )}
      </form>
    </div>
  );
}
