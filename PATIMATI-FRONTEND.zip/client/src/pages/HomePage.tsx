/*
 * Home Page
 * Design: Header with logo + notification bell, search bar, two main tabs
 * (Evcil Hayvanları Sahiplen / Kayıp/Bulunan), horizontal scroll of nearby pets,
 * promotional banner, AI Camera recognition flow in Kayıp/Bulunan tab.
 */

import { useApp } from '@/contexts/AppContext';
import { PawLogo } from '@/components/PawLogo';
import { PetCard } from '@/components/PetCard';
import { BottomNav } from '@/components/BottomNav';
import { MOCK_PETS } from '@/const';
import { Bell, Search, PawPrint, MapPin, Heart, Camera, Sparkles, CheckCircle2, XCircle } from 'lucide-react';
import { useState, useRef, useMemo } from 'react';
import type { Pet } from '@/types';

type MatchResult = {
  pet: Pet;
  confidence: number;
};

export default function HomePage() {
  const { setActiveTab, userListings } = useApp();
  const [mainTab, setMainTab] = useState<'adopt' | 'lost'>('adopt');

  // Use user-generated listings, fallback to demo data
  const pets = userListings.length > 0 ? userListings : MOCK_PETS;
  const adoptPets = pets.filter(p => p.status === 'adoption');
  const lostFoundPets = pets.filter(p => p.status === 'lost' || p.status === 'found');

  // AI Camera Recognition State
  const [aiStep, setAiStep] = useState<'idle' | 'uploading' | 'analyzing' | 'results' | 'no-match'>('idle');
  const [uploadedImage, setUploadedImage] = useState<string | null>(null);
  const [matchResults, setMatchResults] = useState<MatchResult[]>([]);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const simulateAICamera = (imageUrl: string) => {
    setAiStep('uploading');
    setUploadedImage(imageUrl);

    // Simulate upload progress
    setTimeout(() => {
      setAiStep('analyzing');

      // Simulate AI analysis
      setTimeout(() => {
        // 70% chance of finding matches for demo
        const hasMatch = Math.random() > 0.3;

        if (hasMatch) {
          const shuffled = [...lostFoundPets].sort(() => Math.random() - 0.5);
          const results: MatchResult[] = shuffled.slice(0, 3).map((pet, i) => ({
            pet,
            confidence: 92 - i * 18 - Math.random() * 5,
          }));
          setMatchResults(results);
          setAiStep('results');
        } else {
          setAiStep('no-match');
        }
      }, 2000);
    }, 800);
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (ev) => {
        const url = ev.target?.result as string;
        simulateAICamera(url);
      };
      reader.readAsDataURL(file);
    }
  };

  const handleSampleUpload = (sampleUrl: string) => {
    simulateAICamera(sampleUrl);
  };

  const resetAI = () => {
    setAiStep('idle');
    setUploadedImage(null);
    setMatchResults([]);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="min-h-screen bg-[#FFFBF0] pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-[#FFFBF0]/95 backdrop-blur-lg px-4 pt-4 pb-3">
        <div className="flex items-center justify-between">
          <PawLogo size="md" />
          <button className="relative w-10 h-10 bg-white rounded-full flex items-center justify-center shadow-sm">
            <Bell className="w-5 h-5 text-[#78350F]" />
            <span className="absolute -top-0.5 -right-0.5 w-5 h-5 bg-[#D97706] rounded-full text-white text-[10px] font-bold flex items-center justify-center">2</span>
          </button>
        </div>
      </header>

      <div className="px-4 space-y-5">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#92400E]/40" />
          <input
            type="text"
            placeholder="Kayıp veya bulunmuş hayvan ara..."
            className="w-full px-4 py-3.5 pl-12 rounded-xl border-2 border-[#F3E8D0] bg-white text-[#2D1B00] placeholder:text-[#92400E]/30 focus:border-[#D97706] focus:outline-none transition-colors"
          />
        </div>

        {/* Main Tabs */}
        <div className="flex gap-3">
          <button
            onClick={() => { setMainTab('adopt'); resetAI(); }}
            className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-[Quicksand] font-bold text-sm transition-all duration-200 ${
              mainTab === 'adopt'
                ? 'bg-[#FEF3C7] text-[#78350F] shadow-md shadow-amber-200/50'
                : 'bg-white text-[#92400E]/50'
            }`}
          >
            <PawPrint className="w-4 h-4" />
            Evcil Hayvanları Sahiplen
          </button>
          <button
            onClick={() => setMainTab('lost')}
            className={`flex-1 flex items-center justify-center gap-2 py-3.5 rounded-xl font-[Quicksand] font-bold text-sm transition-all duration-200 ${
              mainTab === 'lost'
                ? 'bg-[#FEF3C7] text-[#78350F] shadow-md shadow-amber-200/50'
                : 'bg-white text-[#92400E]/50'
            }`}
          >
            <Camera className="w-4 h-4" />
            Kayıp/Bulunan
          </button>
        </div>

        {/* AI Camera Recognition - Only in Kayıp/Bulunan tab */}
        {mainTab === 'lost' && (
          <div className="bg-white rounded-2xl shadow-md shadow-amber-900/5 overflow-hidden">
            <div className="bg-gradient-to-r from-[#D97706] to-[#B45309] px-5 py-4">
              <div className="flex items-center gap-2.5">
                <div className="w-10 h-10 bg-white/20 rounded-xl flex items-center justify-center">
                  <Camera className="w-5 h-5 text-white" />
                </div>
                <div>
                  <h3 className="font-[Quicksand] font-bold text-white text-base">AI Kamera Tanıma</h3>
                  <p className="text-white/70 text-xs">Fotoğraf yükle, kayıp hayvanları bul</p>
                </div>
              </div>
            </div>

            <div className="p-5">
              {aiStep === 'idle' && (
                <div className="space-y-4">
                  {/* Upload Area */}
                  <input
                    ref={fileInputRef}
                    type="file"
                    accept="image/*"
                    className="hidden"
                    onChange={handleFileSelect}
                  />
                  <button
                    onClick={() => fileInputRef.current?.click()}
                    className="w-full border-2 border-dashed border-[#D97706]/30 rounded-xl p-6 text-center hover:border-[#D97706]/60 transition-colors active:scale-[0.98]"
                  >
                    <div className="w-14 h-14 bg-[#FEF3C7] rounded-full flex items-center justify-center mx-auto mb-3">
                      <Camera className="w-7 h-7 text-[#D97706]" />
                    </div>
                    <p className="font-[Quicksand] font-bold text-[#2D1B00] text-sm">Fotoğraf Yükle</p>
                    <p className="text-xs text-[#92400E]/40 mt-1">Kayıp hayvanın fotoğrafını çek veya galeriden seç</p>
                  </button>

                  {/* Sample Images */}
                  <div>
                    <p className="text-xs text-[#92400E]/50 font-medium mb-2">Veya örnek fotoğraf dene:</p>
                    <div className="flex gap-2">
                      {MOCK_PETS.filter(p => p.status !== 'adoption').slice(0, 3).map((pet) => (
                        <button
                          key={pet.id}
                          onClick={() => handleSampleUpload(pet.image)}
                          className="flex-1 rounded-lg overflow-hidden border-2 border-[#F3E8D0] hover:border-[#D97706] transition-colors"
                        >
                          <img src={pet.image} alt={pet.name} className="w-full h-20 object-cover" />
                        </button>
                      ))}
                    </div>
                  </div>
                </div>
              )}

              {aiStep === 'uploading' && uploadedImage && (
                <div className="space-y-4">
                  <div className="relative rounded-xl overflow-hidden">
                    <img src={uploadedImage} alt="Uploaded" className="w-full h-48 object-cover" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <div className="text-center">
                        <div className="w-12 h-12 border-3 border-white border-t-transparent rounded-full animate-spin mx-auto mb-2" />
                        <p className="text-white text-sm font-semibold">Yükleniyor...</p>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {aiStep === 'analyzing' && uploadedImage && (
                <div className="space-y-4">
                  <div className="relative rounded-xl overflow-hidden">
                    <img src={uploadedImage} alt="Uploaded" className="w-full h-48 object-cover" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
                    {/* Scanning animation */}
                    <div className="absolute inset-x-0 top-0 h-1 bg-[#D97706] animate-[scan_2s_ease-in-out_infinite]"
                         style={{ boxShadow: '0 0 20px 5px rgba(217,119,6,0.4)' }} />
                    <div className="absolute bottom-4 left-4 right-4">
                      <div className="flex items-center gap-2">
                        <Sparkles className="w-4 h-4 text-[#FDE68A] animate-pulse" />
                        <p className="text-white text-sm font-semibold">AI analiz ediliyor...</p>
                      </div>
                      <div className="mt-2 w-full h-2 bg-white/20 rounded-full overflow-hidden">
                        <div className="h-full bg-[#D97706] rounded-full animate-[loading_2s_ease-in-out]" style={{ width: '100%' }} />
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    {['Yüz özellikleri tespit ediliyor...', 'Veritabanında karşılaştırma yapılıyor...', 'Sonuçlar hazırlanıyor...'].map((text, i) => (
                      <div key={i} className="flex items-center gap-2">
                        <div className={`w-5 h-5 rounded-full flex items-center justify-center ${
                          i === 0 ? 'bg-[#65A30D]/20' : 'bg-[#F3E8D0]'
                        }`}>
                          <div className={`w-2 h-2 rounded-full ${
                            i === 0 ? 'bg-[#65A30D]' : 'bg-[#92400E]/30'
                          }`} />
                        </div>
                        <span className={`text-xs ${i === 0 ? 'text-[#2D1B00]' : 'text-[#92400E]/40'}`}>{text}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {aiStep === 'results' && uploadedImage && (
                <div className="space-y-4">
                  <div className="flex items-center gap-2 bg-[#65A30D]/10 rounded-xl p-3">
                    <CheckCircle2 className="w-5 h-5 text-[#65A30D] flex-shrink-0" />
                    <div>
                      <p className="text-sm font-bold text-[#2D1B00]">{matchResults.length} olası eşleşme bulundu!</p>
                      <p className="text-xs text-[#78350F]/50">AI güven skoruna göre sıralandı</p>
                    </div>
                  </div>

                  <div className="space-y-2">
                    {matchResults.map((result, index) => (
                      <button
                        key={result.pet.id}
                        onClick={() => setActiveTab('detail')}
                        className="w-full flex items-center gap-3 bg-white border border-[#F3E8D0] rounded-xl p-3 hover:border-[#D97706] transition-all active:scale-[0.98]"
                        style={{ animationDelay: `${index * 100}ms` }}
                      >
                        <div className="relative w-16 h-16 rounded-lg overflow-hidden flex-shrink-0">
                          <img src={result.pet.image} alt={result.pet.name} className="w-full h-full object-cover" />
                          <div className="absolute bottom-0 left-0 right-0 bg-[#D97706] py-0.5">
                            <p className="text-[9px] font-bold text-white text-center">
                              %{Math.round(result.confidence)}
                            </p>
                          </div>
                        </div>
                        <div className="flex-1 text-left min-w-0">
                          <h4 className="font-[Quicksand] font-bold text-sm text-[#2D1B00]">{result.pet.name}</h4>
                          <p className="text-xs text-[#78350F]/60">{result.pet.breed} · {result.pet.age}</p>
                          <div className="flex items-center gap-1 mt-1">
                            <MapPin className="w-3 h-3 text-[#D97706]" />
                            <span className="text-[10px] text-[#92400E]/50">{result.pet.location}</span>
                          </div>
                        </div>
                        <div className="text-right flex-shrink-0">
                          <span className={`inline-block px-2 py-0.5 rounded-full text-[10px] font-bold ${
                            result.confidence > 80
                              ? 'bg-[#65A30D]/10 text-[#65A30D]'
                              : result.confidence > 60
                              ? 'bg-[#D97706]/10 text-[#D97706]'
                              : 'bg-red-50 text-red-500'
                          }`}>
                            {result.confidence > 80 ? 'Yüksek' : result.confidence > 60 ? 'Orta' : 'Düşük'}
                          </span>
                        </div>
                      </button>
                    ))}
                  </div>

                  <button
                    onClick={resetAI}
                    className="w-full py-2.5 text-sm font-semibold text-[#92400E]/50 hover:text-[#78350F] transition-colors"
                  >
                    Tekrar Tara
                  </button>
                </div>
              )}

              {aiStep === 'no-match' && uploadedImage && (
                <div className="space-y-4">
                  <div className="relative rounded-xl overflow-hidden">
                    <img src={uploadedImage} alt="Uploaded" className="w-full h-48 object-cover opacity-60" />
                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
                      <div className="text-center">
                        <XCircle className="w-12 h-12 text-red-400 mx-auto mb-2" />
                        <p className="text-white text-sm font-semibold">Eşleşme bulunamadı</p>
                      </div>
                    </div>
                  </div>
                  <div className="text-center py-2">
                    <p className="text-sm text-[#78350F]/60">
                      Veritabanımızda bu hayvan ile eşleşen bir kayıt bulunamadı.
                    </p>
                    <p className="text-xs text-[#92400E]/40 mt-1">
                      Kayıp ilanı oluşturabilirsiniz.
                    </p>
                  </div>
                  <div className="flex gap-3">
                    <button
                      onClick={resetAI}
                      className="flex-1 py-3 rounded-xl border-2 border-[#F3E8D0] text-[#78350F] font-[Quicksand] font-bold text-sm active:scale-[0.97] transition-transform"
                    >
                      Tekrar Tara
                    </button>
                    <button
                      onClick={() => setActiveTab('add')}
                      className="flex-1 py-3 rounded-xl bg-[#D97706] text-white font-[Quicksand] font-bold text-sm shadow-md shadow-amber-600/20 active:scale-[0.97] transition-transform"
                    >
                      İlan Oluştur
                    </button>
                  </div>
                </div>
              )}
            </div>
          </div>
        )}

        {/* Nearby Animals Section */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 bg-[#FEF3C7] rounded-lg flex items-center justify-center">
                <PawPrint className="w-4 h-4 text-[#D97706]" />
              </div>
              <h2 className="font-[Quicksand] font-bold text-[#2D1B00]">Yakınındaki Hayvanlar</h2>
            </div>
            <button className="text-sm text-[#D97706] font-semibold">Tümünü Gör →</button>
          </div>

          <div className="flex gap-3 overflow-x-auto pb-2 -mx-4 px-4 scrollbar-hide">
            {(mainTab === 'adopt' ? adoptPets : lostFoundPets).map((pet) => (
              <PetCard key={pet.id} pet={pet} variant="compact" />
            ))}
          </div>
        </div>

        {/* Promo Banner */}
        <div className="bg-gradient-to-r from-[#FEF3C7] to-[#FDE68A] rounded-2xl p-5 flex items-center gap-4">
          <div className="flex-shrink-0">
            <svg viewBox="0 0 80 80" className="w-16 h-16">
              <circle cx="40" cy="40" r="36" fill="#D97706" opacity="0.15" />
              <path d="M30 50c-2 0-4-1-5-3l-8-4c-1-1-1-2 0-3l3-3c1-1 2-1 3 0l4 8c2 1 3 3 3 5z" fill="#D97706" opacity="0.3" />
              <path d="M15 35c-3 0-6-2-6-5s3-5 6-5 6 2 6 5-3 5-6 5zM27 28c-3 0-6-2-6-5s3-5 6-5 6 2 6 5-3 5-6 5zM53 28c3 0 6-2 6-5s-3-5-6-5-6 2-6 5 3 5 6 5zM65 35c3 0 6-2 6-5s-3-5-6-5-6 2-6 5 3 5 6 5zM40 60c-8 0-16-6-16-18 0-5 4-10 9-10 3 0 5 2 7 4 2-2 4-4 7-4 5 0 9 5 9 10 0 12-8 18-16 18z" fill="#D97706" opacity="0.6" />
              <path d="M40 56c-6 0-12-5-12-12 0-4 2-7 5-7 2 0 3 1 4 2 1-1 2-2 4-2 3 0 5 3 5 7 0 7-6 12-12 12z" fill="#D97706" />
            </svg>
          </div>
          <div className="flex-1">
            <h3 className="font-[Quicksand] font-bold text-[#2D1B00] text-sm leading-tight">
              Bir dost kazan,<br />bir hayat değişsin.
            </h3>
            <p className="text-[#78350F]/60 text-xs mt-1">Sahiplen, sevgiye ortak ol.</p>
          </div>
          <button
            onClick={() => setActiveTab('listings')}
            className="flex-shrink-0 bg-[#D97706] text-white text-xs font-bold px-4 py-2 rounded-full active:scale-95 transition-transform"
          >
            Nasıl Sahiplenirim? →
          </button>
        </div>

        {/* All Listings Preview */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="font-[Quicksand] font-bold text-[#2D1B00] text-lg">Tüm İlanlar</h2>
            <button
              onClick={() => setActiveTab('listings')}
              className="text-sm text-[#D97706] font-semibold"
            >
              Tümünü Gör →
            </button>
          </div>
          <div className="space-y-3">
            {MOCK_PETS.slice(0, 3).map((pet) => (
              <PetCard key={pet.id} pet={pet} variant="horizontal" onClick={() => setActiveTab('detail')} />
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
