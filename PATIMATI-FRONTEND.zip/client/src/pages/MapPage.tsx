/*
 * Map Page
 * Design: Full map view with lost (red) and found (green) pins,
 * filter toggles at top, Google Maps InfoWindow popups on pin click
 * showing pet preview with image, name, status, and "Detay Gör" link.
 * Uses Google Maps via the built-in MapView component.
 */

import { useApp } from '@/contexts/AppContext';
import { BottomNav } from '@/components/BottomNav';
import { MapView } from '@/components/Map';
import { MOCK_PETS } from '@/const';
import { Filter, MapPin, Clock, ChevronRight, PawPrint } from 'lucide-react';
import { useState, useCallback, useRef, useEffect } from 'react';
import type { Pet } from '@/types';

// Deterministic positions for demo pins in Istanbul
const PET_POSITIONS: Record<string, google.maps.LatLngLiteral> = {
  '1': { lat: 40.9900, lng: 29.0250 },
  '3': { lat: 41.0180, lng: 29.0200 },
  '5': { lat: 40.9850, lng: 29.0450 },
  '6': { lat: 41.0050, lng: 29.0600 },
};

export default function MapPage() {
  const { setActiveTab, userListings } = useApp();
  const pets = userListings.length > 0 ? userListings : MOCK_PETS;
  const [showLost, setShowLost] = useState(true);
  const [showFound, setShowFound] = useState(true);
  const mapRef = useRef<google.maps.Map | null>(null);
  const markersRef = useRef<google.maps.Marker[]>([]);
  const infoWindowRef = useRef<google.maps.InfoWindow | null>(null);
  const selectedPetIdRef = useRef<string | null>(null);

  const lostPets = pets.filter(p => p.status === 'lost');
  const foundPets = pets.filter(p => p.status === 'found');
  const visiblePets = [...(showLost ? lostPets : []), ...(showFound ? foundPets : [])];

  const createMarkerIcon = (status: string) => ({
    path: google.maps.SymbolPath.CIRCLE,
    scale: 14,
    fillColor: status === 'lost' ? '#DC2626' : '#65A30D',
    fillOpacity: 1,
    strokeColor: '#FFFFFF',
    strokeWeight: 3,
  });

  const createInfoWindowContent = (pet: Pet) => {
    const statusColor = pet.status === 'lost' ? '#DC2626' : '#65A30D';
    const statusText = pet.status === 'lost' ? 'KAYIP' : 'BULUNDU';
    return `
      <div style="font-family: 'Quicksand', sans-serif; min-width: 220px;">
        <div style="display: flex; gap: 12px; align-items: flex-start;">
          <img src="${pet.image}" alt="${pet.name}" style="width: 80px; height: 80px; border-radius: 12px; object-fit: cover; flex-shrink: 0;" />
          <div style="flex: 1; min-width: 0;">
            <div style="display: flex; align-items: center; gap: 6px; margin-bottom: 4px;">
              <span style="font-weight: 700; font-size: 16px; color: #2D1B00;">${pet.name}</span>
              <span style="font-size: 10px; font-weight: 700; padding: 2px 6px; border-radius: 9999px; background: ${statusColor}15; color: ${statusColor};">${statusText}</span>
            </div>
            <p style="font-size: 12px; color: #78350F99; margin: 0;">${pet.breed}</p>
            <div style="display: flex; align-items: center; gap: 4px; margin-top: 6px;">
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="#D97706" stroke-width="2"><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>
              <span style="font-size: 11px; color: #78350F99;">${pet.location}</span>
            </div>
          </div>
        </div>
        <button onclick="window.__pattymatyOpenDetail('${pet.id}')" style="width: 100%; margin-top: 10px; padding: 8px 0; border: none; border-radius: 10px; background: #D97706; color: white; font-family: 'Quicksand', sans-serif; font-weight: 700; font-size: 13px; cursor: pointer;">
          Detay Gör →
        </button>
      </div>
    `;
  };

  // Expose detail navigation globally for InfoWindow button clicks
  useEffect(() => {
    (window as any).__pattymatyOpenDetail = (petId: string) => {
      if (infoWindowRef.current) {
        infoWindowRef.current.close();
      }
      setActiveTab('detail');
    };
    return () => {
      delete (window as any).__pattymatyOpenDetail;
    };
  }, [setActiveTab]);

  const handleMapReady = useCallback((map: google.maps.Map) => {
    mapRef.current = map;
    map.setCenter({ lat: 40.9903, lng: 29.0268 });
    map.setZoom(13);

    // Clear existing markers
    markersRef.current.forEach(m => m.setMap(null));
    markersRef.current = [];

    if (infoWindowRef.current) {
      infoWindowRef.current.close();
    }

    const infoWindow = new google.maps.InfoWindow({
      maxWidth: 260,
    });
    infoWindowRef.current = infoWindow;

    visiblePets.forEach((pet) => {
      const position = PET_POSITIONS[pet.id] || {
        lat: 40.97 + Math.random() * 0.06,
        lng: 29.0 + Math.random() * 0.08,
      };

      const marker = new google.maps.Marker({
        position,
        map,
        title: pet.name,
        icon: createMarkerIcon(pet.status),
      });

      marker.addListener('click', () => {
        // Close previous info window
        if (infoWindowRef.current) {
          infoWindowRef.current.close();
        }

        infoWindow.setContent(createInfoWindowContent(pet));
        infoWindow.open(map, marker);
        selectedPetIdRef.current = pet.id;

        // Fit map to show the marker
        map.panTo(position);
      });

      markersRef.current.push(marker);
    });
  }, [visiblePets, pets]);

  const statusLabel = (status: string) => status === 'lost' ? 'KAYIP' : 'BULUNDU';
  const statusColor = (status: string) => status === 'lost' ? 'red' : 'green';

  return (
    <div className="min-h-screen bg-[#FFFBF0] pb-24">
      {/* Header */}
      <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-lg px-4 pt-4 pb-3 border-b border-[#F3E8D0]">
        <div className="flex items-center justify-between">
          <button
            onClick={() => setActiveTab('home')}
            className="w-10 h-10 rounded-full bg-[#FEF3C7] flex items-center justify-center active:scale-95 transition-transform"
          >
            <svg className="w-5 h-5 text-[#78350F]" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
              <path strokeLinecap="round" strokeLinejoin="round" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
            </svg>
          </button>
          <h1 className="font-[Quicksand] font-bold text-xl text-[#2D1B00]">Harita</h1>
          <button className="w-10 h-10 rounded-full bg-[#FEF3C7] flex items-center justify-center">
            <Filter className="w-5 h-5 text-[#78350F]" />
          </button>
        </div>
      </header>

      {/* Filter Toggles */}
      <div className="px-4 py-3 flex gap-3 bg-white border-b border-[#F3E8D0]">
        <button
          onClick={() => setShowLost(!showLost)}
          className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold transition-all ${
            showLost ? 'bg-red-100 text-red-600' : 'bg-gray-100 text-gray-400'
          }`}
        >
          <MapPin className="w-4 h-4" />
          Kayıp Hayvanlar
          <span className={`w-8 h-4 rounded-full relative transition-colors ${showLost ? 'bg-red-400' : 'bg-gray-300'}`}>
            <span className={`absolute top-0.5 w-3.5 h-3.5 rounded-full bg-white shadow-sm transition-transform ${showLost ? 'left-4' : 'left-0.5'}`} />
          </span>
        </button>
        <button
          onClick={() => setShowFound(!showFound)}
          className={`flex items-center gap-2 px-4 py-2 rounded-full text-sm font-semibold transition-all ${
            showFound ? 'bg-green-100 text-green-600' : 'bg-gray-100 text-gray-400'
          }`}
        >
          <MapPin className="w-4 h-4" />
          Bulunan Hayvanlar
          <span className={`w-8 h-4 rounded-full relative transition-colors ${showFound ? 'bg-green-400' : 'bg-gray-300'}`}>
            <span className={`absolute top-0.5 w-3.5 h-3.5 rounded-full bg-white shadow-sm transition-transform ${showFound ? 'left-4' : 'left-0.5'}`} />
          </span>
        </button>
      </div>

      {/* Map */}
      <div className="h-[calc(100vh-300px)] relative">
        <MapView onMapReady={handleMapReady} />

        {/* Legend */}
        <div className="absolute top-3 right-3 z-30 bg-white/95 backdrop-blur-sm rounded-xl shadow-md px-3 py-2 space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-red-600" />
            <span className="text-[10px] font-semibold text-[#78350F]">Kayıp</span>
          </div>
          <div className="flex items-center gap-2">
            <span className="w-3 h-3 rounded-full bg-[#65A30D]" />
            <span className="text-[10px] font-semibold text-[#78350F]">Bulundu</span>
          </div>
          <p className="text-[9px] text-[#92400E]/40 mt-1">Pin'e tıkla</p>
        </div>
      </div>

      {/* Bottom Slide-up Pet List */}
      <div className="px-4 pb-24">
        <div className="bg-white rounded-2xl shadow-md shadow-amber-900/5 p-4">
          <div className="flex items-center gap-2 mb-3">
            <PawPrint className="w-4 h-4 text-[#D97706]" />
            <h3 className="font-[Quicksand] font-bold text-sm text-[#2D1B00]">
              Haritadaki Hayvanlar ({visiblePets.length})
            </h3>
          </div>
          <div className="space-y-2 max-h-40 overflow-y-auto">
            {visiblePets.map((pet) => (
              <button
                key={pet.id}
                onClick={() => setActiveTab('detail')}
                className="w-full flex items-center gap-3 p-2 rounded-xl hover:bg-[#FFFBF0] transition-colors active:scale-[0.98]"
              >
                <img src={pet.image} alt={pet.name} className="w-10 h-10 rounded-lg object-cover" />
                <div className="flex-1 text-left">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-bold text-[#2D1B00]">{pet.name}</span>
                    <span className={`text-[9px] font-bold px-1.5 py-0.5 rounded-full ${
                      pet.status === 'lost' ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'
                    }`}>
                      {statusLabel(pet.status)}
                    </span>
                  </div>
                  <p className="text-[11px] text-[#78350F]/50">{pet.breed} · {pet.location}</p>
                </div>
                <ChevronRight className="w-4 h-4 text-[#92400E]/30" />
              </button>
            ))}
          </div>
        </div>
      </div>

      <BottomNav />
    </div>
  );
}
