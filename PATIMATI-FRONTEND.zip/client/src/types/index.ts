// Pattymaty Types - Data models for the pet adoption & lost pet tracking app

export type PetType = 'cat' | 'dog';
export type PetGender = 'male' | 'female';
export type ListingStatus = 'adoption' | 'lost' | 'found';

export interface Pet {
  id: string;
  name: string;
  type: PetType;
  breed: string;
  age: string;
  gender: PetGender;
  color: string;
  location: string;
  distance: string;
  image: string;
  status: ListingStatus;
  vaccinated: boolean;
  neutered: boolean;
  houseTrained: boolean;
  description: string;
  contact: string;
  createdAt: string;
  ownerId: string;
  ownerName: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  location: string;
  stats: {
    adoptions: number;
    foundPets: number;
    listings: number;
  };
}

export interface Chat {
  id: string;
  participantName: string;
  participantAvatar: string;
  petName: string;
  lastMessage: string;
  time: string;
  unreadCount: number;
}

export interface Message {
  id: string;
  senderId: string;
  text: string;
  time: string;
}

export interface Notification {
  id: string;
  title: string;
  message: string;
  time: string;
  read: boolean;
  type: 'match' | 'message' | 'alert' | 'adoption';
}
