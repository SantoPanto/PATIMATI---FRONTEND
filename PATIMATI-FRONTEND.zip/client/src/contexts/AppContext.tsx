import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import { MOCK_USER, MOCK_PETS, MOCK_CHATS } from '@/const';
import type { User, Pet, Chat } from '@/types';

interface Message {
  id: string;
  chatId: string;
  senderId: string;
  senderName: string;
  text: string;
  time: string;
}

interface AppContextType {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => void;
  logout: () => void;
  activeTab: string;
  setActiveTab: (tab: string) => void;

  // User-generated listings (dynamic)
  userListings: Pet[];
  addListing: (listing: Pet) => void;
  deleteListing: (id: string) => void;

  // User-generated chats (dynamic)
  chats: Chat[];
  messages: Message[];
  sendMessage: (chatId: string, text: string) => void;
  startChat: (participantName: string, participantAvatar: string, petName: string) => Chat;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [activeTab, setActiveTab] = useState('home');

  // User-generated listings — starts with demo data, users add their own
  const [userListings, setUserListings] = useState<Pet[]>(MOCK_PETS);

  // User-generated chats — starts with demo data, users create new ones
  const [chats, setChats] = useState<Chat[]>(MOCK_CHATS);
  const [messages, setMessages] = useState<Message[]>([]);

  const login = useCallback((_email: string, _password: string) => {
    setUser(MOCK_USER);
  }, []);

  const logout = useCallback(() => {
    setUser(null);
    setActiveTab('home');
  }, []);

  const addListing = useCallback((listing: Pet) => {
    setUserListings(prev => [listing, ...prev]);
  }, []);

  const deleteListing = useCallback((id: string) => {
    setUserListings(prev => prev.filter(l => l.id !== id));
  }, []);

  const sendMessage = useCallback((chatId: string, text: string) => {
    if (!user) return;
    const newMsg: Message = {
      id: `msg-${Date.now()}`,
      chatId,
      senderId: user.id,
      senderName: user.name,
      text,
      time: new Date().toLocaleTimeString('tr-TR', { hour: '2-digit', minute: '2-digit' }),
    };
    setMessages(prev => [...prev, newMsg]);
    setChats(prev =>
      prev.map(c =>
        c.id === chatId
          ? { ...c, lastMessage: text, time: newMsg.time, unreadCount: 0 }
          : c
      )
    );
  }, [user]);

  const startChat = useCallback((participantName: string, participantAvatar: string, petName: string): Chat => {
    const newChat: Chat = {
      id: `chat-${Date.now()}`,
      participantName,
      participantAvatar,
      petName,
      lastMessage: 'Sohbet başladı',
      time: 'Şimdi',
      unreadCount: 0,
    };
    setChats(prev => [newChat, ...prev]);
    return newChat;
  }, []);

  return (
    <AppContext.Provider value={{
      user,
      isAuthenticated: !!user,
      login,
      logout,
      activeTab,
      setActiveTab,
      userListings,
      addListing,
      deleteListing,
      chats,
      messages,
      sendMessage,
      startChat,
    }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const context = useContext(AppContext);
  if (!context) throw new Error('useApp must be used within AppProvider');
  return context;
}
