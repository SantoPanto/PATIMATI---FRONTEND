/*
 * Pattymaty App
 * Mobile-first web prototype with tab-based navigation.
 * Auth gate: shows LoginPage if not authenticated, otherwise shows the tab-based app.
 */

import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import { AppProvider, useApp } from "./contexts/AppContext";
import LoginPage from "./pages/LoginPage";
import HomePage from "./pages/HomePage";
import MapPage from "./pages/MapPage";
import ListingsPage from "./pages/ListingsPage";
import PetDetailPage from "./pages/PetDetailPage";
import ChatPage from "./pages/ChatPage";
import ProfilePage from "./pages/ProfilePage";
import AddListingPage from "./pages/AddListingPage";

function AppContent() {
  const { isAuthenticated, activeTab } = useApp();

  if (!isAuthenticated) {
    return <LoginPage />;
  }

  switch (activeTab) {
    case 'home':
      return <HomePage />;
    case 'map':
      return <MapPage />;
    case 'listings':
      return <ListingsPage />;
    case 'detail':
      return <PetDetailPage />;
    case 'chat':
      return <ChatPage />;
    case 'profile':
      return <ProfilePage />;
    case 'add':
      return <AddListingPage />;
    default:
      return <HomePage />;
  }
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="light">
        <AppProvider>
          <TooltipProvider>
            <Toaster />
            <div className="max-w-lg mx-auto relative min-h-screen bg-[#FFFBF0]">
              <AppContent />
            </div>
          </TooltipProvider>
        </AppProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
