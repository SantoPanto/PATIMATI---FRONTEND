/*
 * Bottom Navigation Component
 * Design: 5 tabs (Ana Sayfa, Harita, Ekle, Sohbet, Profil) with centered large "+" button.
 * Warm amber active state, cream background, paw-print icons.
 */

import { useApp } from '@/contexts/AppContext';
import { Home, MapPin, Plus, MessageCircle, User } from 'lucide-react';

const tabs = [
  { id: 'home', label: 'Ana Sayfa', icon: Home },
  { id: 'map', label: 'Harita', icon: MapPin },
  { id: 'add', label: 'Ekle', icon: Plus, isCenter: true },
  { id: 'chat', label: 'Sohbet', icon: MessageCircle },
  { id: 'profile', label: 'Profil', icon: User },
];

export function BottomNav() {
  const { activeTab, setActiveTab } = useApp();

  return (
    <nav className="fixed bottom-0 left-0 right-0 z-50 bg-white/95 backdrop-blur-lg border-t border-[#F3E8D0] pb-[env(safe-area-inset-bottom)]">
      <div className="max-w-lg mx-auto flex items-center justify-around px-2 py-1.5">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          const isActive = activeTab === tab.id;

          if (tab.isCenter) {
            return (
              <button
                key={tab.id}
                onClick={() => setActiveTab('add')}
                className="relative -mt-5 w-14 h-14 bg-[#D97706] rounded-full flex items-center justify-center shadow-lg shadow-amber-600/30 active:scale-95 transition-transform duration-160"
              >
                <Plus className="w-7 h-7 text-white" strokeWidth={2.5} />
              </button>
            );
          }

          return (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={`flex flex-col items-center gap-0.5 px-3 py-1 transition-colors duration-200 ${
                isActive ? 'text-[#D97706]' : 'text-[#92400E]/50'
              }`}
            >
              <Icon className="w-5 h-5" strokeWidth={isActive ? 2.5 : 2} />
              <span className="text-[10px] font-semibold">{tab.label}</span>
              {isActive && <div className="w-1 h-1 rounded-full bg-[#D97706] mt-0.5" />}
            </button>
          );
        })}
      </div>
    </nav>
  );
}
