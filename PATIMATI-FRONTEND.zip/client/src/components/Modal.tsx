import { cn } from '@/lib/utils';
import { X } from 'lucide-react';
import { type ReactNode } from 'react';

interface ModalProps {
  isOpen: boolean;
  onClose: () => void;
  children: ReactNode;
  title?: string;
  className?: string;
}

export function Modal({ isOpen, onClose, children, title, className }: ModalProps) {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-[100] flex items-end sm:items-center justify-center">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div
        className={cn(
          'relative bg-white rounded-t-3xl sm:rounded-2xl w-full max-w-lg max-h-[85vh] overflow-y-auto animate-in slide-in-from-bottom-4 fade-in duration-300',
          className
        )}
      >
        {title && (
          <div className="sticky top-0 bg-white px-6 py-4 border-b border-[#F3E8D0] flex items-center justify-between rounded-t-3xl sm:rounded-t-2xl z-10">
            <h2 className="font-[Quicksand] font-bold text-lg text-[#2D1B00]">{title}</h2>
            <button onClick={onClose} className="w-8 h-8 rounded-full bg-[#FEF3C7] flex items-center justify-center active:scale-95 transition-transform">
              <X className="w-4 h-4 text-[#78350F]" />
            </button>
          </div>
        )}
        <div className="p-6">{children}</div>
      </div>
    </div>
  );
}
