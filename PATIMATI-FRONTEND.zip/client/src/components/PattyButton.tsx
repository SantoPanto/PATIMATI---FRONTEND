/*
 * Pattymaty Button Component
 * Design: Warm amber primary, rounded corners, paw icon for primary variant.
 * Active state scales to 0.97 for tactile feedback (160ms ease-out).
 */

import { cn } from '@/lib/utils';
import { type ReactNode } from 'react';

interface PattyButtonProps {
  children: ReactNode;
  variant?: 'primary' | 'secondary' | 'outline' | 'ghost';
  size?: 'sm' | 'md' | 'lg';
  icon?: ReactNode;
  className?: string;
  onClick?: () => void;
  type?: 'button' | 'submit';
  disabled?: boolean;
  fullWidth?: boolean;
}

export function PattyButton({
  children,
  variant = 'primary',
  size = 'md',
  icon,
  className,
  onClick,
  type = 'button',
  disabled = false,
  fullWidth = false,
}: PattyButtonProps) {
  const base = 'font-semibold rounded-xl transition-all duration-160 ease-out active:scale-[0.97] inline-flex items-center justify-center gap-2 font-[Quicksand]';

  const variants = {
    primary: 'bg-[#D97706] text-white hover:bg-[#B45309] shadow-md shadow-amber-600/20',
    secondary: 'bg-[#FFFBF0] text-[#78350F] border-2 border-[#D97706] hover:bg-[#FEF3C7]',
    outline: 'bg-transparent text-[#D97706] border-2 border-[#D97706]/30 hover:border-[#D97706] hover:bg-[#D97706]/5',
    ghost: 'bg-transparent text-[#78350F] hover:bg-[#FEF3C7]',
  };

  const sizes = {
    sm: 'px-4 py-2 text-sm',
    md: 'px-6 py-3 text-base',
    lg: 'px-8 py-4 text-lg',
  };

  return (
    <button
      type={type}
      onClick={onClick}
      disabled={disabled}
      className={cn(
        base,
        variants[variant],
        sizes[size],
        fullWidth && 'w-full',
        disabled && 'opacity-50 cursor-not-allowed active:scale-100',
        className
      )}
    >
      {icon}
      {children}
    </button>
  );
}
