/*
 * PetCard Component
 * Design: Rounded card with image, pet info, distance, and action button.
 * Warm earthy tones, soft shadows, paw-print icon on CTA.
 */

import { cn } from '@/lib/utils';
import { Heart, MapPin } from 'lucide-react';
import type { Pet } from '@/types';

interface PetCardProps {
  pet: Pet;
  variant?: 'horizontal' | 'vertical' | 'compact';
  className?: string;
  onClick?: () => void;
  onFavorite?: () => void;
}

export function PetCard({ pet, variant = 'vertical', className, onClick, onFavorite }: PetCardProps) {
  const statusLabel = {
    adoption: 'Sahiplenilmeyi Bekliyor',
    lost: 'Kayıp',
    found: 'Bulundu',
  };

  const statusColor = {
    adoption: 'bg-[#D97706]/10 text-[#D97706]',
    lost: 'bg-red-100 text-red-600',
    found: 'bg-[#65A30D]/10 text-[#65A30D]',
  };

  if (variant === 'compact') {
    return (
      <div
        className={cn(
          'flex-shrink-0 w-40 bg-white rounded-2xl shadow-md shadow-amber-900/5 overflow-hidden cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5',
          className
        )}
        onClick={onClick}
      >
        <div className="relative">
          <img src={pet.image} alt={pet.name} className="w-full h-28 object-cover" />
          <button
            onClick={(e) => { e.stopPropagation(); onFavorite?.(); }}
            className="absolute top-2 right-2 w-7 h-7 bg-white/90 rounded-full flex items-center justify-center shadow-sm"
          >
            <Heart className="w-3.5 h-3.5 text-[#D97706]" />
          </button>
        </div>
        <div className="p-3">
          <h3 className="font-[Quicksand] font-bold text-[#2D1B00] text-sm">{pet.name}</h3>
          <p className="text-[#78350F]/60 text-xs mt-0.5">{pet.breed} - {pet.age}</p>
          <div className="flex items-center gap-1 mt-1.5">
            <MapPin className="w-3 h-3 text-[#D97706]" />
            <span className="text-xs text-[#78350F]/60">{pet.distance}</span>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div
      className={cn(
        'bg-white rounded-2xl shadow-md shadow-amber-900/5 overflow-hidden cursor-pointer transition-all duration-200 hover:shadow-lg hover:-translate-y-0.5',
        variant === 'horizontal' ? 'flex' : '',
        className
      )}
      onClick={onClick}
    >
      <div className={cn('relative', variant === 'horizontal' ? 'w-32 flex-shrink-0' : '')}>
        <img
          src={pet.image}
          alt={pet.name}
          className={cn('w-full object-cover', variant === 'horizontal' ? 'h-full min-h-[140px]' : 'h-48')}
        />
        <button
          onClick={(e) => { e.stopPropagation(); onFavorite?.(); }}
          className="absolute top-3 right-3 w-8 h-8 bg-white/90 rounded-full flex items-center justify-center shadow-sm"
        >
          <Heart className="w-4 h-4 text-[#D97706]" />
        </button>
      </div>
      <div className={cn('p-4 flex-1', variant === 'vertical' && 'flex flex-col')}>
        <div className="flex items-start justify-between">
          <div>
            <h3 className="font-[Quicksand] font-bold text-[#2D1B00] text-lg">{pet.name}</h3>
            <p className="text-[#78350F]/60 text-sm mt-0.5">{pet.age} · {pet.breed}</p>
          </div>
          <span className={cn('text-xs font-semibold px-2.5 py-1 rounded-full whitespace-nowrap', statusColor[pet.status])}>
            {statusLabel[pet.status]}
          </span>
        </div>
        <div className="flex items-center gap-1.5 mt-2">
          <MapPin className="w-3.5 h-3.5 text-[#D97706]" />
          <span className="text-sm text-[#78350F]/60">{pet.location}</span>
          <span className="text-[#D97706]/40 mx-1">|</span>
          <span className="text-sm text-[#D97706]">{pet.distance}</span>
        </div>
        {variant === 'vertical' && (
          <div className="mt-3 pt-3 border-t border-[#F3E8D0] flex items-center justify-between">
            <span className="text-xs text-[#78350F]/50">İlan sahibi: {pet.ownerName}</span>
            <span className="text-xs font-medium text-[#D97706]">Detay Gör →</span>
          </div>
        )}
      </div>
    </div>
  );
}
