import { cn } from '@/lib/utils';

interface PawLogoProps {
  size?: 'sm' | 'md' | 'lg';
  showText?: boolean;
  className?: string;
}

export function PawLogo({ size = 'md', showText = true, className }: PawLogoProps) {
  const sizes = {
    sm: { icon: 'w-6 h-6', text: 'text-base' },
    md: { icon: 'w-8 h-8', text: 'text-xl' },
    lg: { icon: 'w-12 h-12', text: 'text-3xl' },
  };

  return (
    <div className={cn('flex items-center gap-2', className)}>
      <svg viewBox="0 0 48 48" className={cn('text-[#D97706]', sizes[size].icon)} fill="currentColor">
        <path d="M10 14c-2 0-4-1.5-4-3.5S8 7 10 7s4 1.5 4 3.5S12 14 10 14zM18 8c-2 0-4-1.5-4-3.5S16 1 18 1s4 1.5 4 3.5S20 8 18 8zM30 8c2 0 4-1.5 4-3.5S32 1 30 1s-4 1.5-4 3.5S28 8 30 8zM38 14c2 0 4-1.5 4-3.5S40 7 38 7s-4 1.5-4 3.5S36 14 38 14zM24 38c-6 0-12-5-12-14 0-4 3-7 7-7 2 0 4 1 5 2.5 1-1.5 3-2.5 5-2.5 4 0 7 3 7 7 0 9-6 14-12 14z" />
      </svg>
      {showText && (
        <span className={cn('font-[Quicksand] font-bold text-[#2D1B00]', sizes[size].text)}>
          Pattymaty
        </span>
      )}
    </div>
  );
}
