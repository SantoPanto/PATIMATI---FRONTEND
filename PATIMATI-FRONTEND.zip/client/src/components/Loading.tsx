import { cn } from '@/lib/utils';
import { Loader2 } from 'lucide-react';

interface LoadingProps {
  className?: string;
  text?: string;
}

export function Loading({ className, text }: LoadingProps) {
  return (
    <div className={cn('flex flex-col items-center justify-center gap-3 py-12', className)}>
      <Loader2 className="w-8 h-8 text-[#D97706] animate-spin" />
      {text && <p className="text-sm text-[#78350F]/60 font-medium">{text}</p>}
    </div>
  );
}
